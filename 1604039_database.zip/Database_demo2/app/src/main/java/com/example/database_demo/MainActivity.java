package com.example.database_demo;

import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    Button b1,b2;
    EditText e1,e2,e3;
    SQLiteDatabase db;
    String u_name,pass,mo_no;
    Cursor c;
     @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        b1=findViewById(R.id.button);
        b2=findViewById(R.id.button2);
        e1=findViewById(R.id.editText);
        e2=findViewById(R.id.editText2);
        e3=findViewById(R.id.editText3);

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                db=openOrCreateDatabase("RIT",MODE_PRIVATE,null);
                db.execSQL("create table if not exists Login(username Varchar(30), password Varchar(30),mobile Varcha0.r(10))");


                try
                {
                    u_name = e1.getText().toString();
                    pass = e2.getText().toString();
                    mo_no = e3.getText().toString();
                    db.execSQL("insert into Login values('"+u_name+"','"+pass+"','"+mo_no+"')");
                    //
                                       /* ContentValues contentValues=new ContentValues();

                    contentValues.put("U_name",u_name );
                    contentValues.put("ps", pass);
                    contentValues.put("mo", mo_no);

                    db.insertOrThrow("Login", null, contentValues);
                    Toast.makeText(getApplicationContext(),"Registered",Toast.LENGTH_LONG).show();
*/

                    c = db.rawQuery("select * from Login", null);
                   while(c.moveToNext())
                   {
                       String user_name=c.getString(0);
                       String pass=c.getString(1);
                       String mob_no=c.getString(2);
                       Toast.makeText(getApplicationContext(),user_name+"\n"+pass+"\n"+mob_no,Toast.LENGTH_LONG).show();

                   }


                }
                catch(Exception e)
                {

                }
                finally
                {
                    db.close();
                }
            }
        });
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(getApplicationContext(), Login.class);
                startActivity(i);
            }
        });
    }
}
