package com.example.database_demo;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Login extends AppCompatActivity {
EditText e1,e2;
Button b1,b2;
String s1,s2;
Cursor c;
    String s3,s4,s5,s6;
SQLiteDatabase db;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        db=openOrCreateDatabase("RIT",MODE_PRIVATE,null);


        e1=findViewById(R.id.editText4);
        e2=findViewById(R.id.editText5);
        b1=findViewById(R.id.button3);
        b2=findViewById(R.id.button4);
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                s1=e1.getText().toString();
                s2=e2.getText().toString();

                  c=db.rawQuery("select * from Login where username='"+s1+"' and password='"+s2+"'",null);
                while (c.moveToNext())
                {
                   s3=c.getString(0);
                   s4=c.getString(1);
                }
                if(s1.equals(s3) && s2.equals(s4))
                {
                    Toast.makeText(getApplicationContext(),"Success",Toast.LENGTH_LONG).show();
                }
                else
                {
                    Toast.makeText(getApplicationContext(),"Not",Toast.LENGTH_LONG).show();
                }
            }
        });
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                s1=e1.getText().toString();
                s2=e2.getText().toString();
                c=db.rawQuery("update Login set password='"+s2+"' where username='"+s1+"'",null);
                while (c.moveToNext())
                {
                    s5=c.getString(0);
                    s6=c.getString(1);
                }

            }
        });
    }
}
