package com.example.smsmanagerappl;

import android.Manifest;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    Button b1;
    EditText e1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        b1=findViewById(R.id.button);
        e1=findViewById(R.id.editText);
        ActivityCompat.requestPermissions(this,new String[]{Manifest.permission.SEND_SMS},1);

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try
                {
                 String s1=e1.getText().toString();
                    SmsManager mn=SmsManager.getDefault();
                    mn.sendTextMessage("+919975620369","+919890098900",s1,null,null);
                    Toast.makeText(getApplicationContext(),"send successfully!!",Toast.LENGTH_SHORT).show();
                }
                catch (Exception e)
                {
                    Toast.makeText(getApplicationContext(),"Not send",Toast.LENGTH_SHORT).show();
                    e.printStackTrace();
                }
            }
        });



    }
}
