package com.example.mydatabase;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    Button b1,b2,b3,b4;
    EditText e1,e2;
    SQLiteDatabase db;
  //  String s1,s2;
    int flag=0;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        e1=findViewById(R.id.editText2);
        e2=findViewById(R.id.editText3);
        b1=findViewById(R.id.button6);
        b2=findViewById(R.id.button7);
        b3=findViewById(R.id.button8);
        b4=findViewById(R.id.button9);

        db=openOrCreateDatabase("rti",MODE_PRIVATE,null);
        db.execSQL("create table if not exists Stud(name varchar(10),roll varchar(10))");

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String s1,s2;
                s1=e1.getText().toString();
                s2=e2.getText().toString();

                ContentValues cv=new ContentValues();
                cv.put("name",s1);
                cv.put("roll",s2);

                db.insertOrThrow("Stud",null,cv);
                Toast.makeText(getApplicationContext(),"Inserted",Toast.LENGTH_SHORT).show();

                db.close();
            }

        });

        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String s1, s2;
                s1 = e1.getText().toString();
                s2 = e2.getText().toString();

                Cursor c = db.rawQuery("select * from Stud", null);
                while (c.moveToNext())
                {
                    if (s1.equals(c.getString(0)) && (s2.equals(c.getString(1)))) {
                        flag = 1;
                        Toast.makeText(getApplicationContext(), "valid user", Toast.LENGTH_SHORT).show();
                    }

                }
                if (flag == 0)
                {
                    Toast.makeText(getApplicationContext(), "invalid user", Toast.LENGTH_SHORT).show();
                }

                db.close();
            }
        });

        b3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String s1,s2;
                s1=e1.getText().toString();
                s2=e2.getText().toString();

                db.execSQL("update Stud set name='"+s1+"' where roll=='"+s2+"'");
                Toast.makeText(getApplicationContext(),"Updated",Toast.LENGTH_SHORT).show();
            }
        });

    }
}
