package com.example.user.intentdemo;

import android.content.Intent;
import android.net.Uri;
import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
Button call,dial,calllog,gallary,contacts,camera,chrome;

EditText edt;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        call = findViewById(R.id.button2);
        dial = findViewById(R.id.button);
        calllog = findViewById(R.id.button3);
        gallary = findViewById(R.id.button4);
        contacts = findViewById(R.id.button5);
        camera = findViewById(R.id.button6);
        chrome = findViewById(R.id.button8);
        edt = findViewById(R.id.editText);

          call.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
            String s1 = edt.getText().toString();
            Intent i1 = new Intent(Intent.ACTION_CALL,Uri.parse("tel" + s1));
            // i1.setData(Uri.parse(s1));
             startActivity(i1);
            }
        });

         dial.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i2=new Intent(Intent.ACTION_DIAL);
                i2.setData(Uri.parse( "tel:" + edt.getText().toString() ));
                startActivity(i2);
            }
        });

         calllog.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(Intent.ACTION_VIEW,Uri.parse("content://call_log/calls/") );
                startActivity(i);
            }
        });

        gallary.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i3 = new Intent(Intent.ACTION_VIEW,Uri.parse("content://media/external /images/media/"));
                startActivity(i3);
            }
        });

        contacts.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(Intent.ACTION_VIEW,Uri.parse("content://contacts/people/"));
                startActivity(i);
            }
        });

        camera.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                startActivity(i);
            }
        });

        chrome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(Intent.ACTION_VIEW,Uri.parse("http://www.google.com/"));
                startActivity(i);
            }
        });
    }
}
