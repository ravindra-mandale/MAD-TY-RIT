package edureka.com.notification_4017;

import android.app.NotificationManager;
import android.content.Context;
import android.support.v4.app.NotificationBuilderWithBuilderAccessor;
import android.support.v4.app.NotificationCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import java.nio.channels.Channel;

public class MainActivity extends AppCompatActivity {
Button b1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        b1=findViewById(R.id.button1);
      /*  b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                notificationcall();

            }
        });*/
    }
    public void notificationcall(View v){
        NotificationCompat.Builder notification = new NotificationCompat.Builder(this, "channel_id");
                notification.setContentTitle("Notification_AndroidStudio");
        notification.setContentText("Test Message");
        notification.setSmallIcon(R.drawable.a);
            NotificationManager n=(NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            n.notify(1,notification.build());

        //NotificationManager.notify(1, notification.build());
    }

}
