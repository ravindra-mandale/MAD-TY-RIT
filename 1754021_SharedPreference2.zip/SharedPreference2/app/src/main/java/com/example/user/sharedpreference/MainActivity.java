package com.example.user.sharedpreference;

import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
SharedPreferences sp;
SharedPreferences.Editor ed;
String s1,s2;
EditText edt,edt1;
Button btn,btn1,btn2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        edt=findViewById(R.id.editText);
        edt1=findViewById(R.id.editText2);

        btn=findViewById(R.id.button);
        btn1=findViewById(R.id.button2);
        btn2=findViewById(R.id.button3);

        sp=getSharedPreferences("Information",MODE_PRIVATE);
        if(sp.contains("Uname"))
        {
            edt.setText(sp.getString("Uname",s1));
        }
        if(sp.contains("Pass"))
        {
            edt1.setText(sp.getString("Pass",s2));

        }


        btn.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
             s1 = edt.getText().toString();
             s2 = edt1.getText().toString();
            ed =sp.edit();
            ed.putString("Uname",s1);
            ed.putString("Pass",s2);
            ed.commit();
        }

    });

         btn1.setOnClickListener(new View.OnClickListener() {
         @Override
         public void onClick(View v) {
            edt.setText("");
            edt1.setText("");
         }
    });

        btn2.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            String nm=sp.getString("Uname","");
            String p=sp.getString("Pass","");
            edt.setText(nm);
            edt1.setText(p);
        }
    });
    }

}
