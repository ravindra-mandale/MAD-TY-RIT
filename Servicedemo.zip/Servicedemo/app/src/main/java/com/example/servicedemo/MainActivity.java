package com.example.servicedemo;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Log.i("oncrete","Activity Created");
    }
    protected void onStart()
    {
                super.onStart();
                Log.i("onStart()","Activity Started");
    }
    protected void onResume()
    {
               super.onResume();
                Log.i("onStart()","Activity Resumed");
    }
    protected void onaPuse()
    {
                super.onPause();
                Log.i("onStart()","Activity Paused");
    }
    protected void onStop()
    {
                super.onStop();
                Log.i("onStart()","Activity Stoped");
    }
    protected void onDestroy()
    {
                super.onDestroy();
                Log.i("onStart()","Activity Destroyed");
    }

}
