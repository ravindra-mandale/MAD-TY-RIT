package com.example.admin.telephony_and_sms;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.telephony.TelephonyManager;
import android.widget.EditText;
import android.widget.TextView;


public class MainActivity extends AppCompatActivity
{
    EditText ed1;
    TextView tv1;
    TelephonyManager telephonyManager;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ed1=findViewById(R.id.editText1);
        telephonyManager=(TelephonyManager)getSystemService(TELEPHONY_SERVICE);
        String name=telephonyManager.getSimOperatorName();
        int networktype=telephonyManager.getNetworkType();
        int phonetype=telephonyManager.getPhoneType();
        String cname=telephonyManager.getNetworkCountryIso();
        String simname=telephonyManager.getSimCountryIso();
        String ptype=null;
        String ntype=null;

        switch (phonetype)
        {
            case(TelephonyManager.PHONE_TYPE_CDMA):
                ptype="CDMA";
                break;
            case (TelephonyManager.PHONE_TYPE_GSM):
                ptype="GSM";
                break;
            case (TelephonyManager.PHONE_TYPE_NONE):
                ptype="NONE";
                break;

        }
        switch (networktype)
        {
            case(TelephonyManager.NETWORK_TYPE_CDMA):
                ntype="CDMA";
                break;
            case (TelephonyManager.NETWORK_TYPE_GSM):
                ntype="GSM";
                break;
            case (TelephonyManager.NETWORK_TYPE_EDGE):
                ptype="EDGE";
                break;

        }
        String message="Sim Operator name="+name+"\n Network Type="+ntype+"\n Phone Type="+ptype+"\n Network Country="+cname+"\n Sim Country="+simname;
        ed1.setText(message);

    }
}
