package com.example.filehand_demo;

import android.os.Environment;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;

public class MainActivity extends AppCompatActivity {
EditText ed1;
String name="";
File f;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ed1=findViewById(R.id.editText);


    }
    public void write(View view)
    {
    name=ed1.getText().toString();
    try
    {
        OutputStreamWriter osw=new OutputStreamWriter(openFileOutput("student.txt",MODE_PRIVATE));
        osw.write(name);
        osw.close();
    }
    catch (Exception e)
    {
        e.printStackTrace();
    }
    }
    public void read(View view)
    {
        try
        {
            InputStreamReader isr=new InputStreamReader(openFileInput("student.txt"));
            BufferedReader br=new BufferedReader(isr);
            name=br.readLine();
            ed1.setText(name);
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
    }
    public void read_card(View view)
    {
        File ex=Environment.getExternalStorageDirectory();
        String path=ex.getAbsolutePath()+"/"+"student.txt";
        //Toast.makeText(getApplicationContext(),path+"",Toast.LENGTH_LONG).show();
        try
        {
            //f=new File(path);
            FileInputStream f_in=new FileInputStream(path);

            BufferedReader br=new BufferedReader(new InputStreamReader(f_in));
            name=br.readLine();
            ed1.setText(name);
            br.close();
            Toast.makeText(getApplicationContext(),"read",Toast.LENGTH_LONG).show();

        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
    }
    public void write_card(View view)
    {
       String name=ed1.getText().toString();
       File ex=Environment.getExternalStorageDirectory();
       String path=ex.getAbsolutePath()+"/"+"student.txt";
        try
        {
             //f=new File(path);+"/"+"student.txt"
            //f.createNewFile();
            FileOutputStream f_out=new FileOutputStream(path);
            OutputStreamWriter osw=new OutputStreamWriter(f_out);
            osw.append(name);
            osw.close();
            f_out.close();
            Toast.makeText(getApplicationContext(),"hii",Toast.LENGTH_LONG).show();

        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
    }
}
