package com.example.telephony;

import android.Manifest;
import android.content.pm.PackageManager;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.telephony.TelephonyManager;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    TelephonyManager tm;
    TextView tv;
    Button b;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        tm = (TelephonyManager) getSystemService(TELEPHONY_SERVICE);
        tv = findViewById(R.id.textView);

        String simop=tm.getSimOperatorName();
        int net_type=tm.getNetworkType();
        int phonr_type=tm.getPhoneType();
        String cou_name=tm.getNetworkCountryIso();
        String s_coun_name=tm.getSimCountryIso();
        String p_type=null;
        String n_type=null;
        switch (phonr_type)
        {
            case (TelephonyManager.PHONE_TYPE_CDMA):
                p_type="CDMA";
                break;
            case (TelephonyManager.PHONE_TYPE_GSM):
                p_type="GSM";
                break;
            case (TelephonyManager.PHONE_TYPE_SIP):
                p_type="SIP";
                break;
            case (TelephonyManager.PHONE_TYPE_NONE):
                p_type="NONE";
                break;
        }
                switch (net_type)
                {
                    case (TelephonyManager.PHONE_TYPE_CDMA):
                        n_type="CDMA";
                        break;
                    case (TelephonyManager.PHONE_TYPE_GSM):
                        n_type="GSM";
                        break;
                    case (TelephonyManager.PHONE_TYPE_SIP):
                        n_type="SIP";
                        break;
                    case (TelephonyManager.PHONE_TYPE_NONE):
                        n_type="NONE";
                        break;

                }
        String msg="Sim Operator "+simop+"\n"+"Network type "+n_type+"\n"+"Phone Type "+p_type+"\nNetwork Country "+cou_name+"\nSim country "+s_coun_name;
        tv.setText(msg);

    }
}
