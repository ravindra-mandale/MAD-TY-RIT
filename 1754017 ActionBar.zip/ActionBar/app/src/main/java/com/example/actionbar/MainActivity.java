package com.example.actionbar;

import android.app.DatePickerDialog;
import android.content.DialogInterface;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
ActionBar ab;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ab=getSupportActionBar();
       // assert ab !=null;
        ab.setDisplayHomeAsUpEnabled(true);
        ab.setTitle("Aishwarya");
    }



        @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.mymenu,menu);
        return super.onCreateOptionsMenu(menu);

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id=item.getItemId();
        if(id==R.id.item1)
        {
            Toast.makeText(getApplicationContext(),"you select View",Toast.LENGTH_SHORT).show();
        }
        if(id==R.id.item2)
        {
            Toast.makeText(getApplicationContext(),"you select Add",Toast.LENGTH_SHORT).show();
        }
        if(id==R.id.item3)
        {
            Toast.makeText(getApplicationContext(),"you select Delete",Toast.LENGTH_SHORT).show();
            AlertDialog.Builder ad=new AlertDialog.Builder(MainActivity.this);
            ad.setTitle("Delete???");
            ad.setMessage("Do u really want to delete??????");
            ad.setIcon(R.drawable.t1);

            ad.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {

                }

            });

            ad.setNegativeButton("Cancle", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {

                }
            });

            ad.setNeutralButton("Later on", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {

                }
            });

            AlertDialog aa=ad.create();
            aa.show();
        }
        return super.onOptionsItemSelected(item);
    }






}
