package com.example.rit.notification_1754003;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.support.v4.app.NotificationCompat;
import android.support.v4.app.NotificationManagerCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity
{
    Button b1;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        b1=findViewById(R.id.button);
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addnoti();
            }
        });

    }
    public void addnoti()
    {
        NotificationCompat.Builder ncb;
        Intent i=new Intent(MainActivity.this,MainActivity.class);
        PendingIntent pi=PendingIntent.getActivity(this,0,i,PendingIntent.FLAG_UPDATE_CURRENT);
        ncb=new NotificationCompat.Builder(getApplicationContext(),"0");
        ncb.setSmallIcon(R.drawable.ic_launcher_background);
        ncb.setContentTitle("New message received");
        ncb.setContentText("You have received new message...");

        ncb.setContentIntent(pi);
        NotificationChannel channel = new NotificationChannel("0","hello",NotificationManager.IMPORTANCE_HIGH);

        NotificationManager mg=getSystemService(NotificationManager.class);
        mg.createNotificationChannel(channel);

        NotificationManagerCompat nm=NotificationManagerCompat.from(getApplicationContext());
        nm.notify(0,ncb.build());

    }
}
