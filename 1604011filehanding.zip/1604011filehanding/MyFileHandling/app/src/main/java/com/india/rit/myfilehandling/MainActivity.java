package com.india.rit.myfilehandling;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;


public class MainActivity extends AppCompatActivity {

    EditText ed;
    TextView tv;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ed = findViewById(R.id.editText2);
        tv = findViewById(R.id.textView);

    }

    public void readData(View view) {
        try
        {
            InputStreamReader inputStreamReader=new InputStreamReader(openFileInput("read.txt"));
            BufferedReader bufferedReader = new BufferedReader(inputStreamReader);
            String data3= bufferedReader.readLine();
            tv.setText(data3);
            bufferedReader.close();;
            inputStreamReader.close();
        }
        catch (Exception e)
        {

        }


    }

    public void writeData(View view) {
        try {
            String data = ed.getText().toString();
            FileOutputStream fileOutputStream = openFileOutput("read.txt", MODE_PRIVATE);
            fileOutputStream.write(data.getBytes());
            fileOutputStream.close();
        }
        catch (Exception e)
        {

        }
    }

    public void appendData(View view) {
        try
        {
            String data=ed.getText().toString();
            FileOutputStream fileAppend = openFileOutput("read.txt",MODE_APPEND);
            fileAppend.write(data.getBytes());
        }
        catch (Exception e)
        {
            Toast.makeText(getApplicationContext(),e.toString(),Toast.LENGTH_LONG).show();
        }
    }
}
