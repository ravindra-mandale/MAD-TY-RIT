package com.example.user.database;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Login extends AppCompatActivity {
Button b1,b2,b5,b4;
EditText e1,e2;
SQLiteDatabase db1,db2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        b1=findViewById(R.id.bt5);
        b2=findViewById(R.id.bt);
        //b3=findViewById(R.id.bt5);
       // b4=findViewById(R.id.button3);
        b5=findViewById(R.id.button4);
        e1=findViewById(R.id.edittext5);
        e2=findViewById(R.id.editText3);
        db1=openOrCreateDatabase("student",MODE_PRIVATE,null);
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int flag=0;

                Cursor c=db1.rawQuery("select * from login",null);
               // c.moveToLast();
                Toast.makeText(getApplicationContext(),String.valueOf(c.moveToNext()),Toast.LENGTH_LONG).show();

                while (c.moveToNext())
                {
                    String uname=e1.getText().toString();
                    String pass=e2.getText().toString();
                    //Toast.makeText(getApplicationContext(),c.getString(0),Toast.LENGTH_LONG).show();
                        if(uname.equals(c.getString(0)) && pass.equals(c.getString(1)))
                        {
                            //Toast.makeText(getApplicationContext(),"okk",Toast.LENGTH_LONG).show();
                            flag=1;
                        }
                }
                if(flag==1)
                {
                    Toast.makeText(getApplicationContext(),"You have successfully logged in",Toast.LENGTH_LONG).show();
                    Intent i1=new Intent(Login.this,Home.class);
                    startActivity(i1);
                }
                else
                {
                    flag=0;
                    Toast.makeText(getApplicationContext(),"Login failed",Toast.LENGTH_LONG).show();
                }

            }
        });
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                db2=openOrCreateDatabase("student",MODE_PRIVATE,null);
                String newpass=e1.getText().toString();
                String user1=e1.getText().toString();

                Toast.makeText(getApplicationContext(),"Updated",Toast.LENGTH_LONG).show();
            }
        });

        b5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(getApplicationContext(),MainActivity.class);
                startActivity(intent);
            }
        });
    }
}
