package com.example.user.database;

import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
SQLiteDatabase db;
EditText e1,e2,e3;
Button b1,b2;
Cursor c;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        e1=findViewById(R.id.editText);
        e2=findViewById(R.id.editText2);
        e3=findViewById(R.id.edittext5);
        b1=findViewById(R.id.button);
        b2=findViewById(R.id.button2);
           db=openOrCreateDatabase("student",MODE_PRIVATE,null);
           db.execSQL("create table if not exists login (user varchar(10),pass varchar(10))");
           b2.setOnClickListener(new View.OnClickListener() {
               @Override
               public void onClick(View v) {
                   String s1=e1.getText().toString();
                   String s2=e2.getText().toString();
                   ContentValues cv=new ContentValues();
                   cv.put("user",s1);
                   cv.put("pass",s2);
                   db.insertOrThrow("login",null,cv);
                   c=db.rawQuery("select * from login",null);
                   c.moveToLast();
                   String nm=c.getString(0);
                   String ps=c.getString(1);
                   Toast.makeText(getApplicationContext(),"Inserted values are "+nm+" and "+ps,Toast.LENGTH_LONG).show();

               }
           });
       /* db=openOrCreateDatabase("UserDetails",MODE_PRIVATE,null);
        db.execSQL("create table if not exists login(user varchar(10),pass varchar(10),mobile varchar(20))");
      b2.setOnClickListener(new View.OnClickListener() {
          @Override
          public void onClick(View v) {
              String unm=e1.getText().toString();
              String pas=e2.getText().toString();
              String mob=e3.getText().toString();
              ContentValues cv=new ContentValues();
              cv.put("user",unm);
              cv.put("pass",pas);
              cv.put("mobile",mob);
              db.insert("login",null,cv);
              //Cursor c;
              /*c=db.rawQuery("select * from login",null);
              c.moveToLast();
              String nm=c.getString(0);
              String ps=c.getString(1);*/
             // Toast.makeText(getApplicationContext(),"Inserted",Toast.LENGTH_LONG).show();
         // }
     // });


        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(MainActivity.this,Login.class);
                startActivity(i);
            }
        });

    }
}
