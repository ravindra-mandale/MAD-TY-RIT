package com.example.shaired_preference;

import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    EditText e1,e2;
    Button b1,b2,b3;
    SharedPreferences sp;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        b1=findViewById(R.id.button);
        b2=findViewById(R.id.button2);
        b3=findViewById(R.id.button3);
        e1=findViewById(R.id.editText);
        e2=findViewById(R.id.editText2);

        sp= getSharedPreferences("Rit",MODE_PRIVATE);
        if(sp.contains("name"))
        {
            String s1=sp.getString("name","rit");
            e1.setText(s1);
        }
        if(sp.contains("pass"))
        {
            String s2=sp.getString("pass","Rit1");
            e2.setText(s2);
        }


                b1.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        String s1=e1.getText().toString();
                        String s2=e2.getText().toString();
                        SharedPreferences.Editor ed=sp.edit();
                        ed.putString("name",s1);
                        ed.putString("pass",s2);
                        ed.commit();
                        Toast.makeText(getApplicationContext(),"Stored successfully",Toast.LENGTH_LONG).show();

                    }
                });
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String nm=sp.getString("name","okk");
                String pass=sp.getString("pass","okk");
                e1.setText(""+nm);
                e2.setText(""+pass);

            }
        });
        b3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                e1.setText("");
                e2.setText("");
            }
        });
    }



}
