package com.example.lifecycle;

import android.content.DialogInterface;
import android.support.v4.app.BundleCompat;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;


public class MainActivity extends AppCompatActivity {
    Button b1;
    AlertDialog.Builder ad;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Log.i("onCreate()", "Activity Created");
        b1 = findViewById(R.id.button);
        ad=new AlertDialog.Builder(this);
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                ad.setIcon(R.drawable.ic_launcher_background);
                ad.setTitle("Alert Dialog");
                ad.setMessage("Do you want to uninstall?");
                ad.setPositiveButton("Yes", new DialogInterface.OnClickListener()
                {
                    @Override
                    public void onClick(DialogInterface dialog, int which)
                    {
                        Toast.makeText(getApplicationContext(),"Uninstalled",Toast.LENGTH_LONG).show();
                    }
                });
                ad.setNegativeButton("No", new DialogInterface.OnClickListener()
                {
                    @Override
                    public void onClick(DialogInterface dialog, int which)
                    {
                        Toast.makeText(getApplicationContext(),"You pressed No",Toast.LENGTH_LONG).show();
                    }
                });
                ad.setNeutralButton("Cancel", new DialogInterface.OnClickListener()
                {
                    @Override
                    public void onClick(DialogInterface dialog, int which)
                    {
                        Toast.makeText(getApplicationContext(),"You pressed Cancel",Toast.LENGTH_LONG).show();

                    }
                });
                AlertDialog ad1=ad.create();
                ad.show();

            }
        });


    }
    protected void onStart()
    {
        super.onStart();
        Log.i("onStart()","Activity Started");
    }
    protected void onResume()
    {
        super.onResume();
        Log.i("onResume()","Activity Resumed");
    }
    protected void onPause()
    {
        super.onPause();
        Log.i("onPaused","Activity Paused");
    }
    protected void onStop()
    {
        super.onStop();
        Log.i("onStop()","Activity Stoped");

    }
    protected void onRestart()
    {
        super.onRestart();
        Log.i("onRestart()","Activity Restarted");
    }
    protected void onDestroy()
    {
        super.onDestroy();
        Log.i("onDestroy()","Activity Destroyed");
    }
}
