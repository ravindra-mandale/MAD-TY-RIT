package com.example.filehandlingdemo;

import android.Manifest;
import android.os.Environment;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;

public class MainActivity extends AppCompatActivity {
    EditText ed;
    TextView tv;
    public void read(View view)  {

        try {
            InputStreamReader ir=new InputStreamReader(openFileInput("Sachin.txt"));
            BufferedReader br=new BufferedReader(ir);
            String name=br.readLine();
            tv.setText(name);
            //ir.close();
        } catch (IOException e) {
            Toast.makeText(this, "Can't read file", Toast.LENGTH_SHORT).show();
            e.printStackTrace();
        }
    }

    public void write(View view)
    {
        String name=ed.getText().toString();
        try {
            OutputStreamWriter osw = new OutputStreamWriter(openFileOutput("Sachin.txt",MODE_APPEND));
            osw.append(name);
            osw.close();
            Toast.makeText(this, "File written successfully to "+getFilesDir().getAbsolutePath(), Toast.LENGTH_LONG).show();
        } catch (IOException e) {
            Toast.makeText(this, "Can't write file", Toast.LENGTH_SHORT).show();
            e.printStackTrace();
        }

    }
    public void reade(View view)  {

        try{
            File root = android.os.Environment.getExternalStorageDirectory();
            File dir = new File (root.getAbsolutePath() );
            File file = new File(dir, "myData1.txt");
            FileReader pw = new FileReader(file);
            BufferedReader br= new BufferedReader(pw);
            tv.setText(br.readLine());
        } catch (FileNotFoundException e) {
            e.printStackTrace();
            Toast.makeText(this, "Can't read file", Toast.LENGTH_SHORT).show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void writee(View view)
    {

        try {
            File root = android.os.Environment.getExternalStorageDirectory();
            File dir = new File (root.getAbsolutePath() );
            File file = new File(dir, "myData1.txt");
            FileOutputStream f = new FileOutputStream(file);
            PrintWriter pw = new PrintWriter(f);
            pw.println(ed.getText());
            pw.flush();
            pw.close();
            f.close();
            Toast.makeText(this, "File written successfully to "+dir.toString(), Toast.LENGTH_SHORT).show();
        }
        catch (IOException e) {
            Toast.makeText(this, "Can't write file", Toast.LENGTH_SHORT).show();
            e.printStackTrace();
        }

    }
    private void checkExternalMedia(){
        boolean mExternalStorageAvailable = false;
        boolean mExternalStorageWriteable = false;
        String state = Environment.getExternalStorageState();

        if (Environment.MEDIA_MOUNTED.equals(state)) {
            // Can read and write the media
            mExternalStorageAvailable = mExternalStorageWriteable = true;
        } else if (Environment.MEDIA_MOUNTED_READ_ONLY.equals(state)) {
            // Can only read the media
            mExternalStorageAvailable = true;
            mExternalStorageWriteable = false;
        } else {
            // Can't read or write
            mExternalStorageAvailable = mExternalStorageWriteable = false;
        }
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ed=findViewById(R.id.editText);
        tv=findViewById(R.id.textView);
        ActivityCompat.requestPermissions(this,new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE},1);
        checkExternalMedia();
    }
}
