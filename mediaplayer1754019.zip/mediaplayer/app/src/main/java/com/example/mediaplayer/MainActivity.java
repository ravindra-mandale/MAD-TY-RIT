package com.example.mediaplayer;

import android.content.Intent;
import android.media.MediaPlayer;
import android.provider.Settings;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    private Button start,stop;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        start = findViewById(R.id.play);
        stop = findViewById(R.id.stop);

    }
       public void startservice(View view)
        {
            Intent i1=new Intent(this, myservice.class);
            startService(i1);

        }
        public void stopservice(View view)
        {
            Intent i1=new Intent(this, myservice.class);
            stopService(i1);

        }
        public void pause(View view)
        {

        }

}
