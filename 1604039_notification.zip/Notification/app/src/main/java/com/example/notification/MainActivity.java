package com.example.notification;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.support.v4.app.NotificationCompat;
import android.support.v4.app.NotificationManagerCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

Button b1;
    NotificationCompat.Builder builder;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        b1=findViewById(R.id.button);
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addNotification();
            }
        });
    }


    private void addNotification()
    {
        Intent i=new Intent(MainActivity.this,MainActivity.class);
        PendingIntent pi=PendingIntent.getActivity(this,0,i,PendingIntent.FLAG_UPDATE_CURRENT);

        builder=new NotificationCompat.Builder(getApplicationContext(),"0");

        builder.setSmallIcon(R.drawable.ic_launcher_background);
        builder.setContentTitle("Notification");
        builder.setContentText("Battery low");
        builder.setContentIntent(pi);

        NotificationChannel channel=new NotificationChannel("0","Hello",NotificationManager.IMPORTANCE_HIGH);


        NotificationManager manager=getSystemService(NotificationManager.class);
        manager.createNotificationChannel(channel);

        NotificationManagerCompat nmc=NotificationManagerCompat.from(getApplicationContext());

        manager.notify(0,builder.build());
    }
}
