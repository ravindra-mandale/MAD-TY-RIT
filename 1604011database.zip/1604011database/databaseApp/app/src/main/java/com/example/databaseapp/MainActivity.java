package com.example.databaseapp;

import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    EditText e1,e2;
    Button b1,b2;
    SQLiteDatabase db;
    Cursor c;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        e1=findViewById(R.id.editText);
        e2=findViewById(R.id.editText2);
        b1=findViewById(R.id.button);
        b2=findViewById(R.id.button2);

        db=openOrCreateDatabase("register",MODE_PRIVATE,null);
        db.execSQL("create table if not exists register(name Varchar(10),Password Varchar(20))");
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String s1=e1.getText().toString();
                String s2=e2.getText().toString();

                ContentValues cv=new ContentValues();

                cv.put("name",s1);
                cv.put("Password",s2);

                db.insertOrThrow("register",null,cv);
                c=db.rawQuery("Select * from register",null);
                c.moveToNext();
                String Username=c.getString(0);
                String pass=c.getString(1);

                Toast.makeText(getApplicationContext(),Username+"and"+pass,Toast.LENGTH_LONG).show();

                e1.setText("");
                e2.setText("");
                db.close();
            }
        });
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(getApplicationContext(),login.class);
                startActivity(i);

            }
        });


    }
}
