package com.example.databaseapp;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class login extends AppCompatActivity {

    EditText e1,e2;
    Button b1;
    Cursor c1;
    int flag=0;
    SQLiteDatabase db;
    String unm, ps;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        e1 = findViewById(R.id.editText3);
        e2 = findViewById(R.id.editText4);
        b1 = findViewById(R.id.button3);



        db = openOrCreateDatabase("register", MODE_PRIVATE, null);
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                unm = e1.getText().toString();
                ps = e2.getText().toString();
                c1=db.rawQuery("select * from register",null);
                while (c1.moveToNext()) {
                    if (unm.equals(c1.getString(0)) && ps.equals(c1.getString(1))) {
                        flag = 1;
                        Intent i2 = new Intent(getApplicationContext(), newpage.class);
                        startActivity(i2);
                    }
                }
                if (flag == 0) {
                    Toast.makeText(getApplicationContext(), "invalid user", Toast.LENGTH_LONG).show();
                }
            }
        });

    }






}
