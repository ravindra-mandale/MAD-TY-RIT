package com.example.database;

import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    Button b1,b2;
    EditText e1,e2,e3;
    SQLiteDatabase db;
    String u_name,pass,mo_no;
    Cursor c;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        b1=findViewById(R.id.button);
        b2=findViewById(R.id.button2);
        e1=findViewById(R.id.editText);
        e2=findViewById(R.id.editText2);
        e3=findViewById(R.id.editText5);

        db=openOrCreateDatabase("rit",MODE_PRIVATE,null);


    }
    public void reg(View v)
    {
        db=openOrCreateDatabase("RIT",MODE_PRIVATE,null);
        db.execSQL("create table if not exists Login(username Varchar(30), password Varchar(30),mobile Varchar(10))");


        try
        {
            u_name = e1.getText().toString();
            pass = e2.getText().toString();
            mo_no = e3.getText().toString();
            db.execSQL("insert into Login values('"+u_name+"','"+pass+"','"+mo_no+"')");

            c = db.rawQuery("select * from Login", null);
            while(c.moveToNext())
            {
                String user_name=c.getString(0);
                String pass=c.getString(1);
                String mob_no=c.getString(2);
                Toast.makeText(getApplicationContext(),user_name+"\n"+pass+"\n"+mob_no,Toast.LENGTH_LONG).show();

            }


        }
        catch(Exception e)
        {

        }
        finally
        {
            db.close();
        }

    }
    public  void login(View v)
    {
        Intent i=new Intent(this,login.class);
        startActivity(i);

    }
}
