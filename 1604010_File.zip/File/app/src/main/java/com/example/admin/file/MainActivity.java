package com.example.admin.file;

import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;

public class MainActivity extends AppCompatActivity {
    EditText editText1;
    TextView textView1;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        editText1=findViewById(R.id.editText1);
        textView1=findViewById(R.id.textView1);

    }
    public void Write(View view)
    {
        String name=editText1.getText().toString();
        try
        {
             OutputStreamWriter outputStreamWriter= new OutputStreamWriter(openFileOutput("student.txt",MODE_PRIVATE));
             outputStreamWriter.write(name);
             outputStreamWriter.close();
             textView1.clearComposingText();
             Toast.makeText(getApplicationContext(),"Data is written",Toast.LENGTH_LONG).show();
        }
        catch (FileNotFoundException e)
        {
            e.printStackTrace();
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }
    }
    public void Read(View view)
    {
        textView1.clearComposingText();
        try {
            InputStreamReader inputStreamReader=new InputStreamReader(openFileInput("student.txt"));
            BufferedReader bufferedReader=new BufferedReader(inputStreamReader);
            String name=bufferedReader.readLine();
            textView1.setText(name);
            //Toast.makeText(getApplicationContext()," ",Toast.LENGTH_LONG).show();

        }
        catch (FileNotFoundException e)
        {
            e.printStackTrace();
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }

    }
    public  void Clear(View view)
    {
        textView1.clearComposingText();
    }
}
