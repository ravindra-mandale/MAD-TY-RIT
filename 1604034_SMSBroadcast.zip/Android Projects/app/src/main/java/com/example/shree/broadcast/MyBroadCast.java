package com.example.shree.broadcast;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.telephony.SmsMessage;
import android.util.Log;

public class MyBroadCast extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent)
    {
        Bundle b=intent.getExtras();
        Object o[]=(Object[])b.get("pdus");
        SmsMessage sms=SmsMessage.createFromPdu((byte[])o[0]);
        Log.i("sender",sms.getOriginatingAddress());
        Log.i("mea",sms.getDisplayMessageBody());
    }
}
