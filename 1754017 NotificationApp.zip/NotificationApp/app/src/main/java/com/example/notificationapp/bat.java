package com.example.notificationapp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Spinner;

public class bat extends AppCompatActivity {
Spinner sp;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
       /* setContentView(R.layout.activity_bat);

        sp.findViewById(R.id.spinner);
        String []a={"Teacher","Student"};
        ArrayAdapter aa=new ArrayAdapter(this,android.R.layout.simple_spinner_item,a);
        aa.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        sp.setAdapter(aa);*/




    }
}
