package com.example.notificationapp;

import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.os.Message;
import android.support.v4.app.NotificationBuilderWithBuilderAccessor;
import android.support.v4.app.NotificationCompat;
import android.support.v4.app.NotificationManagerCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
Button b1;
    NotificationCompat.Builder nc;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        b1=findViewById(R.id.button);
        nc=new NotificationCompat.Builder(this,null);

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
              //  nc.setPriority(NotificationManagerCompat)
                nc.setSmallIcon(R.drawable.s2);
                nc.setContentTitle("Low Battery");
                nc.setContentText("Please conect ur charger");

                Intent i=new Intent(getApplicationContext(),bat.class);
                PendingIntent pi=PendingIntent.getActivity(MainActivity.this,0,i,PendingIntent.FLAG_UPDATE_CURRENT);
                nc.setContentIntent(pi);

                NotificationManager nm=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);
                nm.notify(0,nc.build());

            }


        });
    }
}
