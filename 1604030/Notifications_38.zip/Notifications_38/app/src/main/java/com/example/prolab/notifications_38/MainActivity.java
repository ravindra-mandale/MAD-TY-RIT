package com.example.prolab.notifications_38;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.support.v4.app.NotificationCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    Button not;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        not=findViewById(R.id.button);

        not.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(v.getContext(), Result.class);
                PendingIntent pIntent = PendingIntent.getActivity(v.getContext(),1, intent, 0);

//


                Notification noti = new Notification.Builder(v.getContext())
                        .setContentTitle("Notification:" + "New notification")
                        .setContentText("Details").setSmallIcon(R.drawable.ic_launcher_background)
                        .setContentIntent(pIntent)
                       // .addAction(R.drawable.ic_launcher_foreground, "More", pIntent)
                        .build();
                NotificationManager notificationManager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
                // hide the notification after its selected
                noti.flags |= Notification.FLAG_AUTO_CANCEL;

                notificationManager.notify(0, noti);


            }
        });


    }
}
