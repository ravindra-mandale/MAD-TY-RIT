package com.example.shared_preference;

import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
SharedPreferences sp;
SharedPreferences.Editor se;
    EditText e1,e2;
    Button b1,b2,b3;
    String s1,s2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        e1=findViewById(R.id.editText);
        e2=findViewById(R.id.editText2);

        b1=findViewById(R.id.button);
        b2=findViewById(R.id.button2);
        b3=findViewById(R.id.button3);

        sp=getSharedPreferences("Information",MODE_PRIVATE);
        if(sp.contains("shital"))
        {
            e1.setText(sp.getString("shital",s1));
        }
        if(sp.contains("patil"))
        {
            e2.setText(sp.getString("patil",s2));
        }
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                s1=e1.getText().toString();
                s2=e2.getText().toString();
                se=sp.edit();
                se.putString("shital",s1);
                se.putString("patil",s2);
                se.commit();
                Toast.makeText(getApplicationContext(),"data Stored",Toast.LENGTH_LONG).show();
            }
        });
        b3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                e1.setText(null);
                e2.setText(null);
                Toast.makeText(getApplicationContext(),"data Cleared",Toast.LENGTH_LONG).show();
            }
        });
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String nm=sp.getString("shital","");
                String ps=sp.getString("patil","");
                e1.setText(nm);
                e2.setText(ps);
                Toast.makeText(getApplicationContext(),"data Retrive",Toast.LENGTH_LONG).show();
            }
        });
    }
}
