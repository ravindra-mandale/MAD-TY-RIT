package com.example.admin.intentdemo;

import android.content.Intent;
import android.net.Uri;
import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivityIntentDemo extends AppCompatActivity {

    //EditText ed1;
    //Button b1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_intent_demo);
        //ed1=TextView.findViewById(R.id.EditText);
        //b1=findViewById(R.id.button1);
    }
    public void button1 (View view)
    {
        Intent i= new Intent(Intent.ACTION_DIAL, Uri.parse("tel:7744948168"));
        //i.setData(Uri.parse("tel: "+ ed1.getText().toString()));
        startActivity(i);
    }
     public void button2 (View view) {
         Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse("content://contacts/people/"));
         startActivity(i);
     }
public void button3 (View view)
{
Intent i= new Intent(Intent.ACTION_VIEW, Uri.parse("http:url"));
startActivity(i);
}
public void button4 (View view)
{
Intent i= new Intent(Intent.ACTION_VIEW, Uri.parse("content://call_log/calls/"));
startActivity(i);
}
public void button5 (View view)
{
Intent i= new Intent(Intent.ACTION_VIEW, Uri.parse("content://media/external/images/media/"));
startActivity(i);
}
public void button6 (View view)
{
Intent i= new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
startActivity(i);
}
public void button7 (View view)
{
Intent i= new Intent(Intent.ACTION_CALL, Uri.parse("phone number"));
startActivity(i);
}
}
