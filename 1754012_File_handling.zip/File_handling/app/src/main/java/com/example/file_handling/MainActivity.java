package com.example.file_handling;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;

public class MainActivity extends AppCompatActivity {
EditText e1;
TextView t1;
Button r,w;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        e1=findViewById(R.id.editText);
        t1=findViewById(R.id.textView);
        r=findViewById(R.id.button);
        w=findViewById(R.id.button2);
        w.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try{
                    String s1=e1.getText().toString();
                    OutputStreamWriter o=new OutputStreamWriter(openFileOutput("demo.txt",MODE_PRIVATE));
                    o.write(s1);
                    o.close();
                }
                catch (FileNotFoundException e)
                {

                }
                catch (IOException e2)
                {

                }
            }
        });
        r.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try{
                    InputStreamReader i=new InputStreamReader(openFileInput("demo.txt"));
                    BufferedReader b=new BufferedReader(i);
                    String data=b.readLine();
                    t1.setText(data);
                    Toast.makeText(getApplicationContext(),getFilesDir().getAbsolutePath(),Toast.LENGTH_LONG).show();
                }
                catch (FileNotFoundException e)
                {

                }
                catch (IOException e2)
                {

                }
            }
        });
    }
}
