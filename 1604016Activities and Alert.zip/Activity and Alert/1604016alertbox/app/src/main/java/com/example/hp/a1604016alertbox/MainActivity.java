package com.example.hp.a1604016alertbox;

import android.content.DialogInterface;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    public Button btn1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btn1=findViewById(R.id.button);

        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder ad = new AlertDialog.Builder(MainActivity.this);
                ad.setIcon(R.drawable.ic_launcher_background);
                ad.setTitle("Alert");
                ad.setMessage(" U are in Main Activity");
                ad.setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        //dialog.cancel();
                        Toast.makeText(getApplicationContext(),"Cancelled",Toast.LENGTH_LONG).show();
                    }
                });
                ad.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                      //  finish();
                        Toast.makeText(getApplicationContext(),"close",Toast.LENGTH_LONG).show();
                    }
                });
                AlertDialog ab=ad.create();
                ab.show();
            }
        });

    }



    }

