package com.example.hp.a1604016activity;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Log.i("oncreate()","Created");
    }
    protected void onStart()
    {
        super.onStart();
        Log.i("onstart()","started ");
    }
    protected void onResume()
    {
        super.onResume();
        Log.i("onresume()","on resume");
    }
    protected void onPause()
    {
        super.onPause();
        Log.i("onpause()","on pause");
    }
    protected void onStop()
    {
        super.onStop();
        Log.i("onstop()","on stop");
    }
    protected void onRestart()
    {
        super.onRestart();
        Log.i("onrestart()","on restart ");
    }
    protected void onDestroy()
    {
        super.onDestroy();
        Log.i("ondestroy()","on destroy ");
    }

    public void Next(View view)
    {
        Intent i=new Intent(this,second.class);
        startActivity(i);
    }





}
