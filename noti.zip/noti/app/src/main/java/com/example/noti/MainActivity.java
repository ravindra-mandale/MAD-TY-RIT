package com.example.noti;

import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.support.v4.app.NotificationCompat;
import android.support.v4.app.Person;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    Button b1;

    NotificationCompat.Builder builder;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        b1=findViewById(R.id.button);
        builder=new NotificationCompat.Builder(this,"abc");
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                NotificationCompat.Builder setSmallIcon=builder.setSmallIcon(R.drawable.ic_launcher_background);
                builder.setContentTitle("My notification");
                builder.setContentText("much longer text");

                Intent i1=new Intent(MainActivity.this,second.class);
                PendingIntent pendingIntent=PendingIntent.getActivity(MainActivity.this,0,i1,PendingIntent.FLAG_UPDATE_CURRENT);
                builder.setContentIntent(pendingIntent);
                NotificationManager manager= (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
                manager.notify(1,builder.build());

            }
        });
    }
}
