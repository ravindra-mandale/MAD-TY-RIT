package com.example.dbdemo;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity
{
    EditText ed1,ed2;
    TextView tv;

    Cursor c;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ed1=findViewById(R.id.editText1);
        ed2=findViewById(R.id.editText2);
        tv=findViewById(R.id.textView);
    }
    public void writeData(View view)
    {
        SQLiteDatabase myDatabase;

        myDatabase=openOrCreateDatabase("register",MODE_PRIVATE,null);
        myDatabase.execSQL("create table if not exists register(name Varchar(10),Password Varchar(20))");
        try
        {
            String s1=ed1.getText().toString();
            String s2=ed2.getText().toString();

            ContentValues cv=new ContentValues();

            cv.put("name",s1);
            cv.put("Password",s2);

            myDatabase.insertOrThrow("register",null,cv);
            c=myDatabase.rawQuery("Select * from register",null);
            c.moveToNext();
            String Username=c.getString(0);
            String pass=c.getString(1);
            Toast.makeText(getApplicationContext(),Username+" and "+pass,Toast.LENGTH_LONG).show();


        }
        catch (Exception e)
        {
            Toast.makeText(getApplicationContext(), e.toString(), Toast.LENGTH_SHORT).show();
        }


    }
}
