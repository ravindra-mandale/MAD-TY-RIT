package com.example.optionmenu;

import android.content.Intent;
import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu)
    {
        MenuInflater mi=getMenuInflater();
        mi.inflate(R.menu.rit,menu);


        return super.onCreateOptionsMenu(menu);

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item)
    {
        int id1=item.getItemId();
       if(id1==R.id.item1);
        {
            Toast.makeText(getApplicationContext(), "started", Toast.LENGTH_LONG).show();
            Intent i = new Intent(getApplicationContext(), my.class);
            startService(i);
        }
        if(id1==R.id.item2)
        {
           Toast.makeText(getApplicationContext(),"stoped",Toast.LENGTH_LONG).show();
            Intent i=new Intent(getApplicationContext(),my.class);
            stopService(i);

        }
        if(id1==R.id.item3)
        {
            Intent i1=new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            startActivity(i1);
        }
        if(id1==R.id.item4)
        {
            Intent i=new Intent(this,shared.class);
            startActivity(i);
        }




        return super.onOptionsItemSelected(item);
    }
}
