package radioactiveyak_com.android.database;

import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import static android.widget.Toast.LENGTH_LONG;

public class MainActivity extends AppCompatActivity {
EditText e1,e2,e3;
Button b1,b2,b5,b6;
SQLiteDatabase db;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        e1=findViewById(R.id.editText3);
        e2=findViewById(R.id.editText4);
        e3=findViewById(R.id.editText4);
        b1=findViewById(R.id.button3);
        b2=findViewById(R.id.button4);
        b5=findViewById(R.id.button5);
        b6=findViewById(R.id.button6);
        db=openOrCreateDatabase("saloni",MODE_PRIVATE,null);
        db.execSQL("create table if not exists login(name varchar(20),pass varchar(10),phone int(10))");
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Cursor c;
                String s1,s2,s3;
                int n;
                s1=e1.getText().toString();
                s2=e2.getText().toString();
                s3=e3.getText().toString();
             //   n=Integer.parseInt(e3.getText().toString());
                ContentValues values=new ContentValues();
                values.put("name",s1);
                values.put("pass",s2);
                values.put("phone",s3);

                db.insertOrThrow("login",null,values);
                c=db.rawQuery("select * from login",null);
                c.moveToNext();
                String nm=c.getString(0);
                String pass=c.getString(1);
                String ph=c.getString(2);
                //int n1=c.getInt(2);
                Toast.makeText(getApplicationContext(),"nm "+nm+"pass "+pass+"no "+ph,Toast.LENGTH_SHORT).show();

                e1.setText("");
                e2.setText("");
                e3.setText("");

                db.close();
            }
        });
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(MainActivity.this,Login.class);
                startActivity(i);
            }
        });
        b5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Cursor c;
                String s1,s2,s3,s4;
                int n;
                s4=e1.getText().toString();
                s1=e1.getText().toString();
                s2=e2.getText().toString();
                s3=e3.getText().toString();
                //   n=Integer.parseInt(e3.getText().toString());
                ContentValues values=new ContentValues();
                values.put("name",s1);
                values.put("pass",s2);
                values.put("phone",s3);

                if (s4.equals("")){
                    Toast.makeText(getApplicationContext(),"plz enter name",LENGTH_LONG).show();
                }

               // db.insertOrThrow("login",null,values);
                c=db.rawQuery("select * from login where name='"+s4+"'",null);
                if(c.moveToFirst()) {
                    db.execSQL("update login set name=" + s1 + " where nmae=" + s4 + "");
                    Toast.makeText(getApplicationContext(), "updated", Toast.LENGTH_SHORT).show();

                   String nm=c.getString(0);
                   String pass=c.getString(1);

                    Toast.makeText(getApplicationContext(),"nm "+nm+"pass "+pass,Toast.LENGTH_SHORT).show();

                }
                else
                {
                    Toast.makeText(getApplicationContext(),"error",Toast.LENGTH_SHORT).show();

                }
                e1.setText("");
                e2.setText("");
                e3.setText("");

                db.close();
            }
        });
        b6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String s=e1.getText().toString();
                if(s.equals("")){
                    Toast.makeText(getApplicationContext(),"enter nm to delete",LENGTH_LONG).show();
                }
                Cursor c=db.rawQuery("select * from login where name='"+s+"'",null);
                if (c.moveToFirst()){
                    db.execSQL("delete from login where name='"+s+"'");
                    Toast.makeText(getApplicationContext(),"deleted",LENGTH_LONG).show();

                }
                else {
                    Toast.makeText(getApplicationContext(),"data not found",LENGTH_LONG).show();

                }
            }
        });
    }
}
