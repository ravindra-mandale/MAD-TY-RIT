package radioactiveyak_com.android.database;

import android.content.Intent;
import android.database.Cursor;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Login extends MainActivity {
EditText e,e4;
    int f;
Button b3,b4;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        b3=findViewById(R.id.button);
        b4=findViewById(R.id.button2);

        e=findViewById(R.id.editText);
        e4=findViewById(R.id.editText2);

        db=openOrCreateDatabase("saloni",MODE_PRIVATE,null);

        b3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String unm,pass;
                Cursor c1;

                unm=e.getText().toString();
                pass=e4.getText().toString();
                c1=db.rawQuery("select * from login",null);
                while (c1.moveToNext()){
                if (unm.equals(c1.getString(0)) && pass.equals(c1.getString(1))){
                f=1;
                   startActivity(new Intent(Login.this,Home.class));
                }
                }
                if (f==0) {
                    Toast.makeText(getApplicationContext(), "invalid usr", Toast.LENGTH_SHORT).show();

                }
            }
            });
        b4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(Login.this,MainActivity.class);
                startActivity(i);
            }
        });
    }
}

