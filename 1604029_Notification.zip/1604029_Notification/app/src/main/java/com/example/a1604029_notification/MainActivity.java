package com.example.a1604029_notification;

import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.support.v4.app.NotificationCompat;
import android.support.v4.app.NotificationManagerCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    Button btn;
    NotificationCompat.Builder nb;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btn=findViewById(R.id.button2);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                nb.setPriority(NotificationManagerCompat.IMPORTANCE_HIGH);
                nb.setSmallIcon(R.drawable.piece);
                nb.setContentTitle("Battery Notification");
                nb.setContentText("Battery Low");
                Intent intent=new Intent(MainActivity.this,Batterys.class);
                PendingIntent pi=PendingIntent.getActivity(MainActivity.this,0,intent,PendingIntent.FLAG_UPDATE_CURRENT);
                nb.setContentIntent(pi);
                NotificationManager mg=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);
                mg.notify(1,nb.build());

            }
        });

    }
}
