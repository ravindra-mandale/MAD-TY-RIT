package com.example.sharedpreferenceapp;

import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
EditText e1,e2;
Button b1,b2,b3;
SharedPreferences sp;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        e1=findViewById(R.id.editText1);
        e2=findViewById(R.id.editText2);
        b1=findViewById(R.id.btncreate);
        b2=findViewById(R.id.btnretrive);
        b3=findViewById(R.id.btnclear);

        sp=getSharedPreferences("Collage",MODE_PRIVATE);
        if (sp.contains("name"))
        {
            e1.setText(sp.getString("name","collage"));
        }
        if(sp.contains("pass"))
        {
            e1.setText(sp.getString("pass","collage1"));

        }

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String s1=e1.getText().toString();
                String s2=e2.getText().toString();
                SharedPreferences.Editor ed=sp.edit();
                ed.putString("name",s1);
                ed.putString("pass",s2);
                ed.commit();
                Toast.makeText(getApplicationContext(),"Stored Successfully",Toast.LENGTH_LONG).show();

            }
        });
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String nm=sp.getString("name","okk");
                String pass=sp.getString("pass","okk");
                e1.setText("+nm");
                e2.setText("+pass");

            }
        });
        b3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                e1.setText("");
                e2.setText("");
            }
        });
    }
}
