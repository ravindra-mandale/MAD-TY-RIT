package com.example.user.change_activity;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    Button btn_lgn, btn_rst;
    TextView tv;
    EditText usr_nm, pwd;
    Spinner sp;
    String f_nm = "faculty", f_pwd="faculty", s_nm="student", s_pwd="student";
    String a_nm="assistant", a_pwd="assistant";
    int f;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tv = findViewById(R.id.textView);
        usr_nm = findViewById(R.id.user_text);
        pwd = findViewById(R.id.pwd_text);
        btn_lgn = findViewById(R.id.lgn_btn);
        btn_rst = findViewById(R.id.rst_btn);
        sp = findViewById(R.id.spinner);

        btn_rst.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                usr_nm.setText("");
                pwd.setText("");
            }
        });

        String spnn[] = new String[] {"Faculty", "Student", "Assistant"};
        ArrayAdapter<String> aa = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, spnn);
        aa.setDropDownViewResource(android.R.layout.simple_list_item_single_choice);
        sp.setAdapter(aa);

        sp.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if(parent.getItemAtPosition(position).equals("Faculty"))
                {
                    f=1;
                }
                if(parent.getItemAtPosition(position).equals("Student"))
                {
                    f=2;
                }
                if(parent.getItemAtPosition(position).equals("Assistant"))
                {
                    f=3;
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                Toast.makeText(getApplicationContext(), "No Item Selected", Toast.LENGTH_SHORT).show();
            }
        });

        btn_lgn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String nm, pass;
                nm = usr_nm.getText().toString();
                pass = pwd.getText().toString();

                if(f_nm.equals(nm) && f_pwd.equals(pass) && f==1)
                {
                    Toast.makeText(getApplicationContext(), "Faculty Login Successfull", Toast.LENGTH_SHORT).show();
                    usr_nm.setText("");
                    pwd.setText("");
                    Intent f =new Intent(v.getContext(), Faculty.class);
                    startActivity(f);
                }

                if(s_nm.equals(nm) && s_pwd.equals(pass) && f==2)
                {
                    Toast.makeText(getApplicationContext(), "Student Login Successfull", Toast.LENGTH_SHORT).show();
                    Intent f =new Intent(v.getContext(), Student.class);
                    usr_nm.setText("");
                    pwd.setText("");
                    startActivity(f);
                }

                if(a_nm.equals(nm) && a_pwd.equals(pass) && f==3)
                {
                    Toast.makeText(getApplicationContext(), "Assistant Login Successfull", Toast.LENGTH_SHORT).show();
                    Intent f =new Intent(v.getContext(), Assistant.class);
                    usr_nm.setText("");
                    pwd.setText("");
                    startActivity(f);
                }

                else
                {
                    Toast.makeText(getApplicationContext(), "Login Credentials Incorrect", Toast.LENGTH_SHORT).show();
                }


            }
        });
    }
}
