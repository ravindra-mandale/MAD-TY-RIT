package com.example.user.change_activity;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;

public class Student extends AppCompatActivity {

    ImageView img;
    ImageButton btn_img;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student);


        img = findViewById(R.id.img_view);
        btn_img = findViewById(R.id.img_btn);


        btn_img.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                img.setImageResource(R.mipmap.s2);
            }
        });
    }
}
