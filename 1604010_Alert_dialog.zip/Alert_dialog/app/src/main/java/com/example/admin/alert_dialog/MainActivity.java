package com.example.admin.alert_dialog;

/*import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
*/
import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RatingBar;
import android.widget.SeekBar;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Arrays;

public class MainActivity extends AppCompatActivity {
AlertDialog.Builder alertDialog;
Button b1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        b1=findViewById(R.id.button1);
    }
    public void alert(View v) {
        alertDialog = new AlertDialog.Builder(this);
        alertDialog.setIcon(R.drawable.ic_launcher_foreground);
        alertDialog.setMessage("Are you confirm");
        alertDialog.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

                Toast.makeText(getApplicationContext(), "ok is clicked", Toast.LENGTH_SHORT).show();
                finish();
            }
        });
        alertDialog.setNegativeButton("cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {


                Toast.makeText(getApplicationContext(), "cancel is clicked", Toast.LENGTH_SHORT).show();
                dialog.cancel();
            }
        });
        alertDialog.setNeutralButton("may be later", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

                Toast.makeText(getApplicationContext(), "may be later is clicked", Toast.LENGTH_SHORT).show();
            }
        });
        AlertDialog ad = alertDialog.create();
        ad.show();
    }
    public void withMultiChoiceItems(View view) {
        final String[] items = {"Apple", "Banana", "Orange", "Grapes"};
        final ArrayList<Integer> al = new ArrayList<>();
        AlertDialog.Builder ab = new AlertDialog.Builder(this);

        ab.setTitle("This is list choice dialog box");
        ab.setMultiChoiceItems(items, null,new DialogInterface.OnMultiChoiceClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which, boolean isChecked) {
                if (isChecked) {
                    al.add(which);
                } else if (al.contains(which)) {
                    al.remove(which);
                }
            }
        });

        ab.setPositiveButton("DONE", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                ArrayList<String> as = new ArrayList<>();
                for (int j = 0; j < al.size(); j++) {
                    as.add(items[al.get(j)]);
                }
                Toast.makeText(getApplicationContext(), "Items selected are: " + Arrays.toString(as.toArray()), Toast.LENGTH_SHORT).show();
            }
        });
        ab.show();
    }
    public void with_edit_text(View v)
    {
        AlertDialog.Builder ab=new AlertDialog.Builder(this);
        ab.setTitle("With Editable Text");

        final EditText i= new EditText(MainActivity.this);
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,LinearLayout.LayoutParams.MATCH_PARENT);
        i.setLayoutParams(lp);
        ab.setView(i);
        ab.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Toast.makeText(getApplicationContext(),"Text entered is" +i.getText().toString(),Toast.LENGTH_SHORT).show();
            }

        });
        ab.show();
    }
    public void seek_bar(View v)
    {
        AlertDialog.Builder ab=new AlertDialog.Builder(this);
        ab.setTitle("Seek Bar");

        final SeekBar sb=new SeekBar(MainActivity.this);
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,LinearLayout.LayoutParams.MATCH_PARENT);
        sb.setLayoutParams(lp);
        ab.setView(sb);

        ab.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Toast.makeText(getApplicationContext(),"progress is"+sb.getProgress(),Toast.LENGTH_SHORT).show();
            }
        });
        ab.show();
    }




}
