package com.example.user.intents;

import android.content.Intent;
import android.net.Uri;
import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    private EditText text;
    private Button btn_call, btn_dial, btn_cam, btn_gallery, btn_browser, btn_log, btn_contact;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        text = findViewById(R.id.editText);
        btn_call = findViewById(R.id.call_btn);
        btn_browser = findViewById(R.id.browser_btn);
        btn_cam = findViewById(R.id.cam_btn);
        btn_contact = findViewById(R.id.contact_btn);
        btn_dial = findViewById(R.id.dial_btn);
        btn_gallery = findViewById(R.id.gallery_btn);
        btn_log = findViewById(R.id.log_btn);

        btn_contact.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse("content://contacts/people/"));
                startActivity(i);
            }
        });

        btn_log.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse("content://call_log/calls/"));
                startActivity(i);
            }
        });

        btn_dial.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String nm = text.getText().toString();
                Intent i = new Intent(Intent.ACTION_DIAL, Uri.parse("tel: +91"+nm));
                startActivity(i);
            }
        });

        btn_call.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String nm = text.getText().toString();
                Intent i = new Intent(Intent.ACTION_CALL, Uri.parse("tel: +91"+nm));
                startActivity(i);
            }
        });

        btn_cam.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                startActivity(i);
            }
        });

        btn_gallery.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse("content://media/external/images/media/"));
                startActivity(i);
            }
        });

        btn_browser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse("http://www.ritindia.edu"));
                startActivity(i);
            }
        });
    }
}
