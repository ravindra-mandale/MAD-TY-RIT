package edu.rit.app.databasesqlite;

import android.content.Intent;
import android.database.Cursor;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class Activity2 extends AppCompatActivity {
Myhelper mh;
EditText e4,e5;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_2);
        mh=new Myhelper(this);
        e4=findViewById(R.id.editText4);
        e5=findViewById(R.id.editText5);
    }
    public void login(View view)
    {
        int flg=0;
        Cursor ch= mh.fetch();

        while (ch.moveToNext())
        {
            String unm=e4.getText().toString();
            String pwd=e5.getText().toString();
            if(unm.equals(ch.getString(0))&&pwd.equals(ch.getString(1)))
            {
                flg=1;
            }
        }
        if(flg==1)
        {
            Toast.makeText(getApplicationContext(),"ok",Toast.LENGTH_LONG).show();
            Intent i=new Intent(Activity2.this,NEW.class);
            startActivity(i);

        }
        else
        {
            Toast.makeText(getApplicationContext(),"Invalid user",Toast.LENGTH_LONG).show();
        }


    }

}
