package edu.rit.app.databasesqlite;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class Myhelper extends SQLiteOpenHelper {
    SQLiteDatabase db;
    public Myhelper(Context context)
    {
        super(context,"DB.db",null,1);
    }
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table login(nm varchar(10),pwd varchar(10))");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }

    public void insertData(String s1,String s2) {
       SQLiteDatabase db1= getWritableDatabase();
        ContentValues v=new ContentValues();

        v.put("nm",s1);
        v.put("pwd",s2);
       db1.insert("login",null,v);
    }

    public Cursor fetch()
    {
        SQLiteDatabase db2=getWritableDatabase();
        Cursor c=db2.rawQuery("select *from login",null);
        return  c;
    }
}

