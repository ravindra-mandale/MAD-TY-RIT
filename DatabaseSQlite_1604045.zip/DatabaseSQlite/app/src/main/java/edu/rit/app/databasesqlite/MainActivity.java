package edu.rit.app.databasesqlite;

import android.content.Intent;
import android.database.Cursor;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
EditText e1,e2,e3;
Myhelper mh;
Button b1,b2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        e1=findViewById(R.id.editText);
        e2=findViewById(R.id.editText2);
        e3=findViewById(R.id.editText3);
        b1=findViewById(R.id.button);
        b2=findViewById(R.id.button2);
        mh=new Myhelper(this);
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                mh.insertData(e1.getText().toString(),e2.getText().toString());
                Log.i("insert data", "onClick:values inserted");
            }
        });
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(MainActivity.this,Activity2.class);
                startActivity(i);
            }
        });
    }


    public void insertRecords(View view)
    {
        String  s1=e1.getText().toString();
        String s2=e2.getText().toString();
        mh.insertData(s1,s2);


    }


}
