package com.example.notificationdemo;

import android.support.v4.app.NotificationCompat;
import android.support.v4.app.NotificationManagerCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity
{

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    public void notify(View v)
    {
        NotificationCompat.Builder nb=new NotificationCompat.Builder(this,"myChannelID");
        nb.setContentTitle("First Notification");
        nb.setSmallIcon(R.mipmap.ic_launcher_round);
        nb.setContentText("This is first notification");
        nb.setAutoCancel(false);
        NotificationManagerCompat nm=NotificationManagerCompat.from(this);
        nm.notify(999,nb.build());
    }
}
