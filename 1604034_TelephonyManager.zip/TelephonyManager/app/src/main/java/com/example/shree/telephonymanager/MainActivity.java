package com.example.shree.telephonymanager;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.telephony.TelephonyManager;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    TelephonyManager tm;
    TextView t1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        t1=findViewById(R.id.textView2);

        tm=(TelephonyManager) getSystemService(TELEPHONY_SERVICE);

        String name=tm.getSimOperatorName();
        int networkType=tm.getNetworkType();

        int phoneType=tm.getPhoneType();
        String cname=tm.getNetworkCountryIso();
        String simname=tm.getSimCountryIso();

        String ptype=null;
        String ntype=null;

        switch (networkType)
        {
            case (TelephonyManager.NETWORK_TYPE_CDMA):
                ntype="CDMA";
                break;

            case (TelephonyManager.NETWORK_TYPE_GSM):
                ntype="GSM";
                break;

            case (TelephonyManager.NETWORK_TYPE_EDGE):
                ntype="EDGE";
                break;

        }

        switch (phoneType)
        {
            case (TelephonyManager.PHONE_TYPE_CDMA):
                ptype="CDMA";
                break;

            case (TelephonyManager.PHONE_TYPE_GSM):
                ptype="GSM";
                break;

            case (TelephonyManager.PHONE_TYPE_NONE):
                ntype="NONE";
                break;
        }
        String msg="Sim Operator = "+name+"\nNetwork Type = "+ntype+"\nPhone Type = "+ptype+"\nNetwuork Country Code = "+cname+"\nSim Name = "+simname;
        t1.setText(msg);
    }
}
