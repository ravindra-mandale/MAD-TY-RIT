package com.example.database;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Login extends AppCompatActivity {
EditText e1,e2;
Button b1,b2,b3,b4;
int flag=0;
SQLiteDatabase db;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        e1=findViewById(R.id.editText3);
        e2=findViewById(R.id.editText5);

        b2=findViewById(R.id.button3);
        b1=findViewById(R.id.button4);
        db=openOrCreateDatabase("RIT",MODE_PRIVATE,null);
    }
    public void onclick(View view) {
        String s1, s2, s3, s4;
        s1 = e1.getText().toString();
        s2 = e2.getText().toString();

        Cursor c = db.rawQuery("select *from login", null);

        while (c.moveToNext()) {
            s3=c.getString(0);
            s4=c.getString(1);
            if (s1.equals(s3) && s2.equals(s4)) {
                flag = 1;
                Toast.makeText(getApplicationContext(), "Login successful", Toast.LENGTH_LONG).show();
                Intent i = new Intent(this, Hello.class);
                startActivity(i);
                e1.setText("");
                e2.setText("");
            }
        }
        if (flag == 0)
        {
            Toast.makeText(getApplicationContext(), "Login invalid", Toast.LENGTH_LONG).show();
            e1.setText("");
            e2.setText("");
        }

    }
public void update_s(View view)
{
    String s5=e1.getText().toString();
    String s6=e2.getText().toString();
    db.execSQL("Update login set pass='"+s6+"' where name='"+s5+"'" );
    Toast.makeText(getApplicationContext(), "updated succesfully", Toast.LENGTH_LONG).show();

}

    public void Del(View view)
    {
        String s5=e1.getText().toString();
        db.execSQL("Delete From login where name='"+s5+"'" );
        Toast.makeText(getApplicationContext(), "Deleted successfully", Toast.LENGTH_LONG).show();
        e1.setText("");
        e2.setText("");
    }
    public void start(View view)
    {
        Intent i=new Intent(getApplicationContext(),MainActivity.class);
        startActivity(i);
    }
}
