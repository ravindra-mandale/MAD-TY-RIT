package com.example.prolab.pr3;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements
        AdapterView.OnItemSelectedListener {

    Button bl,br;
    Spinner spin;
    EditText t1,t2;
    String [] list={"Teacher","student","Lab Assitant"};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        bl=findViewById(R.id.button);
        br=findViewById(R.id.button2);
        t1=findViewById(R.id.editText2);
        t2=findViewById(R.id.editText3);
         spin=findViewById(R.id.spinner);
        spin.setOnItemSelectedListener(this);
        ArrayAdapter a = new ArrayAdapter(this,android.R.layout.simple_spinner_item,list);
        a.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spin.setAdapter(a);
        bl.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String s = spin.getSelectedItem().toString();
                Toast.makeText(getApplicationContext(), s, Toast.LENGTH_LONG).show();
                String ss = String.valueOf(t1.getText());
                String p = String.valueOf(t2.getText());
                if (ss.equals(p)) {
                    if (s.equals("Teacher")) {
                        Intent intent = new Intent(getApplicationContext(), Teacher.class);
                        startActivity(intent);
                    }
                    else if (s.equals("student")) {
                        Intent intent1 = new Intent(getApplicationContext(), Student.class);
                        startActivity(intent1);
                    }
                    else if (s.equals("Lab Assitant")) {
                        Intent intent2 = new Intent(getApplicationContext(), Lab_ass.class);
                        startActivity(intent2);
                    }
                }
            }
        });
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        //Toast.makeText(this,list[position],Toast.LENGTH_LONG).show();

    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }
}
