package com.example.tele_mgm;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.telephony.TelephonyManager;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
    EditText e1;
    TelephonyManager tm;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        e1 = findViewById(R.id.editText);

        tm = (TelephonyManager) getSystemService(TELEPHONY_SERVICE);
        String simop = tm.getSimOperatorName();
        int networktype = tm.getNetworkType();
        int phonetype = tm.getPhoneType();
        String cname = tm.getNetworkCountryIso();
        String sname = tm.getSimCountryIso();
        String ptype = null;
        String ntype = null;
        switch (phonetype)
        {
            case  (TelephonyManager.PHONE_TYPE_CDMA):
                ptype="CDMA";
                break;
            case  (TelephonyManager.PHONE_TYPE_GSM):
                ptype="GSM";
                break;

            case  (TelephonyManager.PHONE_TYPE_NONE):
                ptype="NONE";
                break;


        }
        switch (networktype)
        {
            case  (TelephonyManager.PHONE_TYPE_CDMA):
                ntype="CDMA";
                break;
            case  (TelephonyManager.PHONE_TYPE_GSM):
                ntype="GSM";
                break;

            case  (TelephonyManager.PHONE_TYPE_NONE):
                ntype="NONE";
                break;

        }
        String message="Sim Operator name="+simop+"\n Network Type="+ntype+"\n Phone Type="+ptype+"\n Network Country="+cname+"\n Sim county="+sname+"";
        e1.setText(message);
        String s1="name is"+simop+" surname is="+ntype+"";
    }
}
