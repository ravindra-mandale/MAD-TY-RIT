package com.example.telephonedemo;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.telephony.TelephonyManager;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity
{
    TelephonyManager telephonyManager;
    TextView textView;
    @Override
    protected void onCreate(Bundle savedInstanceState)

    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        textView=findViewById(R.id.textView);
        telephonyManager= (TelephonyManager) getSystemService(TELEPHONY_SERVICE);
        String simName=telephonyManager.getSimOperatorName();
        int networkType=telephonyManager.getNetworkType();
        String networkTypes;
        switch (networkType)
        {
            case TelephonyManager.NETWORK_TYPE_GPRS:
                networkTypes="GPRS";
                break;
            case TelephonyManager.NETWORK_TYPE_EDGE:
                networkTypes="EDGE";
                break;
            case TelephonyManager.NETWORK_TYPE_UNKNOWN:
                networkTypes="Unknown";
                break;
            case TelephonyManager.NETWORK_TYPE_UMTS:
                networkTypes="UMTS";
                break;
                default:
                    networkTypes="None";

        }


        int phoneType=telephonyManager.getPhoneType();
        String phoneName;
        switch (phoneType)
        {
            case TelephonyManager.PHONE_TYPE_CDMA:
                phoneName="CDMA";
                break;
            case TelephonyManager.PHONE_TYPE_GSM:
                phoneName="GSM";
                break;
            case TelephonyManager.PHONE_TYPE_NONE:
                phoneName="NONE";
                break;
                default:phoneName="Unknown";
        }
        String countryIsoCode=telephonyManager.getNetworkCountryIso();
        String iso=telephonyManager.getSimCountryIso();
        textView.setText(simName+"\n"+countryIsoCode+"\n"+iso+"\n"+networkTypes+"\n"+phoneName);
//        int imei=telephonyManager.getImei();
    }
}
