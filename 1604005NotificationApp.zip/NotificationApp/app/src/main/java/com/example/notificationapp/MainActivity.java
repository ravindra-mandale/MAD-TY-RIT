package com.example.notificationapp;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.os.Build;
import android.support.annotation.RequiresApi;
import android.support.v4.app.NotificationCompat;
import android.support.v4.app.NotificationManagerCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    @RequiresApi(api = Build.VERSION_CODES.O)
    public void addnotification(View view)
    {
        NotificationCompat.Builder builder=new NotificationCompat.Builder(getApplicationContext(),"0");

        builder.setSmallIcon(R.drawable.ic_launcher_foreground);
        builder.setContentTitle("Notification");
        builder.setContentText("Battery low");

        Intent i=new Intent(MainActivity.this,second.class);
        PendingIntent pi=PendingIntent.getActivity(this,0,i,PendingIntent.FLAG_UPDATE_CURRENT);

        builder.setContentIntent(pi);

        

        NotificationChannel channel=new NotificationChannel("0","Hello", NotificationManager.IMPORTANCE_HIGH);

        NotificationManager manager=getSystemService(NotificationManager.class);
        manager.createNotificationChannel(channel);

        NotificationManagerCompat nmc=NotificationManagerCompat.from(getApplicationContext());

        manager.notify(0,builder.build());

    }

}
