package com.shital.intent;

import android.content.Intent;
import android.net.Uri;
import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class implicit extends AppCompatActivity {
 EditText e1;
  Button call,Dialpad,browser,galary,call_log,camera,contact;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_implicit);
        e1 = findViewById(R.id.editText);
        call = findViewById(R.id.button);
        Dialpad = findViewById(R.id.button5);
        contact = findViewById(R.id.button6);
        browser = findViewById(R.id.button7);
        call_log = findViewById(R.id.button8);
        camera = findViewById(R.id.button10);
        galary = findViewById(R.id.button9);

        call.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                String s1=e1.getText().toString();
                Intent i=new Intent(Intent.ACTION_CALL,Uri.parse("tel:"+s1));
                startActivity(i);
            }
        });

        Dialpad.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                Intent i=new Intent(Intent.ACTION_DIAL,Uri.parse("tel:7058215545"));
                startActivity(i);
            }
        });

        contact.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                Intent i=new Intent(Intent.ACTION_VIEW,Uri.parse("content://contacts//people/"));
                startActivity(i);
            }
        });

        browser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                Intent i=new Intent(Intent.ACTION_VIEW,Uri.parse("http://www.google.com"));
                startActivity(i);
            }
        });
        call_log.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                Intent i=new Intent(Intent.ACTION_VIEW,Uri.parse("content://call_log/calls/"));
                startActivity(i);
            }
        });
        camera.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                Intent i=new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                startActivity(i);
            }
        });
        galary.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                Intent i=new Intent(Intent.ACTION_VIEW, Uri.parse("content://media/external/images/media/"));
                startActivity(i);
            }
        });
    }

}
