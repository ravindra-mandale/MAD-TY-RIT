package com.example.hp.filehandling1604016;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;

public class MainActivity extends AppCompatActivity {
TextView t1;
EditText e1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        e1=findViewById(R.id.e);
        t1=findViewById(R.id.textView);
    }
    public void write(View view)
    {
        try
        {
            String path=e1.getText().toString();
            OutputStreamWriter o=new OutputStreamWriter(openFileOutput("C:\\Users\\HP\\Desktop\\p.txt",MODE_PRIVATE));
            o.write(path);
            o.close();
            Toast.makeText(getApplicationContext(),"Data written",Toast.LENGTH_LONG).show();
        }
        catch(FileNotFoundException e)
        {

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public void read(View view)
    {
        try
        {
            InputStreamReader isr=new InputStreamReader(openFileInput("C:\\Users\\HP\\Desktop\\p.txt"));
            BufferedReader io=new BufferedReader(isr);
            String path=io.readLine();
            t1.setText(path);
        }
        catch(FileNotFoundException e)
        {

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
