package com.example.mediaplayer;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    Button b1,b2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        b1=findViewById(R.id.btn_start);
        b2=findViewById(R.id.btn_stop);
    }
    public void start(View view)
    {
        Intent i=new Intent(this,second.class);
        startService(i);
    }
    public  void stop(View view)
    {
        Intent i=new Intent(this,second.class);
        stopService(i);

    }

}
