package edu.rit.app.notification;

import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.support.v4.app.NotificationCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import java.nio.channels.Channel;

public class MainActivity extends AppCompatActivity {
    Button b1;
    String abc;
    NotificationCompat.Builder builder;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        builder =new NotificationCompat.Builder(this,abc);

        setContentView(R.layout.activity_main);
        b1=findViewById(R.id.button);
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                builder.setSmallIcon(R.drawable.ic_launcher_background);
                builder.setContentTitle("My notification");
                builder.setContentText("Much longer text");
                //builder.setStyle(new NotificationCompat.BigTextStyle().bigText("Much longer text"));
                //builder.setPriority(NotificationCompat.PRIORITY_DEFAULT);

                Intent i=new Intent(MainActivity.this,second.class);
                PendingIntent pendingIntent=PendingIntent.getActivity(MainActivity.this,0,i,PendingIntent.FLAG_UPDATE_CURRENT);
                builder.setContentIntent(pendingIntent);
                NotificationManager notificationManager=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);

                notificationManager.notify(1,builder.build());

            }
        });

    }
}
