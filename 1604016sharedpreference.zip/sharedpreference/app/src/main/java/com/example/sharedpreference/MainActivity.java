package com.example.sharedpreference;

import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
Button b1,b2;
EditText e1,e2;
SharedPreferences sp;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        b1=findViewById(R.id.button);
        b2=findViewById(R.id.button2);
        b1=findViewById(R.id.button3);
        e1=findViewById(R.id.editText);
        e2=findViewById(R.id.editText2);
        sp=getSharedPreferences("RIT",MODE_PRIVATE);

        if(sp.contains("name"))
        {
            e1.setText(sp.getString("name","rit"));
        }
        if(sp.contains("pass"))
        {
            e2.setText(sp.getString("pass","okkk"));

        }
    }
    public  void store(View v)
    {
        String name=e1.getText().toString();
        String pass=e2.getText().toString();

        SharedPreferences.Editor ed=sp.edit();
        ed.putString("name",name);
        ed.putString("pass",pass);
        ed.commit();
        Toast.makeText(getApplicationContext(), "Successfully stored", Toast.LENGTH_SHORT).show();
    }

    public void returns(View v)
    {
        String nm=sp.getString("name","RIT");
        String ad=sp.getString("pass","okkk");

        e1.setText(""+nm);
        e2.setText(""+ad);

    }
    public void clear(View v)
    {
        e1.setText("");
        e2.setText("");
    }
}
