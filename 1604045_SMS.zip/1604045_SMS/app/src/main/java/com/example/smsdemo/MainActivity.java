package com.example.smsdemo;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
EditText msg;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        msg=findViewById(R.id.messageText);
    }

    public void sendMessage(View view)
    {

        String message= String.valueOf(msg.getText());
        if(message.equals(""))
        {
            Log.e("Error","Cannot be empty");
        }
        else
        {
            SmsManager smsManager=SmsManager.getDefault();
            smsManager.sendTextMessage("+917304292526",null,message,null,null);
        }

//        Toast.makeText(getApplicationContext(),"Message Sent",Toast.LENGTH_LONG).show();
    }
}
