package com.example.admin.optionmenu;

import android.content.Intent;
import android.media.MediaPlayer;
import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;

public class MainActivity_optionmenu extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_optionmenu);
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.optionmenu,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int itemid=item.getItemId();
        if(itemid==R.id.camera)
        {
            Intent intent1=new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            startActivity(intent1);
            return true;
        }

        else if (itemid==R.id.audio)
        {
            Intent intent2=new Intent(this,audio.class);
            startActivity(intent2);
            return true;
        }
        else if(itemid==R.id.video)
        {
            Intent intent3=new Intent(this,Video.class);
            startActivity(intent3);
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
