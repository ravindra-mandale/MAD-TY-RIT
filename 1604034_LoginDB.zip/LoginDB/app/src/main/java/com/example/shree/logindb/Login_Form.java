package com.example.shree.logindb;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Login_Form extends AppCompatActivity {

    Button b1,b2;
    EditText e1,e2;
    Cursor c1;
    SQLiteDatabase db;
    int flag=0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login__form);

        b1=findViewById(R.id.button5);
        b2=findViewById(R.id.button6);
        e1=findViewById(R.id.editText6);
        e2=findViewById(R.id.editText7);

        db = openOrCreateDatabase("Login",MODE_PRIVATE,null);
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String unm ,ps;
                unm=e1.getText().toString();
                ps=e2.getText().toString();

                c1=db.rawQuery("select * from Login",null);
                while (c1.moveToNext()){
                    if(unm.equals(c1.getString(0)) && ps.equals(c1.getString(1)))
                    {
                        flag=1;
                        Intent i2 =new Intent(getApplicationContext(),Home.class);
                        startActivity(i2);
                    }
                }
                if(flag==0)
                {
                    Toast.makeText(getApplicationContext(),"Invalid User",Toast.LENGTH_LONG).show();
                }

            }
        });
                    b2.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            Intent i3 =new Intent(getApplicationContext(),MainActivity.class);
                            startActivity(i3);
                        }
                    });





    }
}
