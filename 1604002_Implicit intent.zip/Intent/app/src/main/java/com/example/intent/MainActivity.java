package com.example.intent;

import android.content.Intent;
import android.net.Uri;
import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    public void browse(View view)
    {
        Intent i=new Intent(Intent.ACTION_VIEW, Uri.parse("http:www.google.com"));
        startActivity(i);
    }
    public void dial(View view){
        Intent i=new Intent(Intent.ACTION_DIAL, Uri.parse("tel:8208851745"));
        startActivity(i);

    }
    public void contact(View view)
    {
        Intent i=new Intent(Intent.ACTION_VIEW, Uri.parse("content://contacts/people/"));
        startActivity(i);
    }
    public void camera(View view)
    {
        Intent i=new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        startActivity(i);
    }
    public void call(View view)
    {
        Intent i=new Intent(Intent.ACTION_CALL,Uri.parse("tel:8208851745"));
        startActivity(i);
    }
    public void gallery(View view)
    {
        Intent i=new Intent(Intent.ACTION_VIEW,Uri.parse("content://media/external/images/media/"));
        startActivity(i);
    }
}
