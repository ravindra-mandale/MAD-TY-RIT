package com.example.a10yearcha;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;

public class Faculty extends AppCompatActivity {
    ImageButton ib,b1;
    ImageView i;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_faculty);


            ib=findViewById(R.id.imageButton2);
            i=findViewById(R.id.imageView);
            ib.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    i.setImageResource(R.drawable.f3);
                }
            });
    }
}
