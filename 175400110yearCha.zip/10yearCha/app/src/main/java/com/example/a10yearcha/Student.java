package com.example.a10yearcha;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;

public class Student extends AppCompatActivity {

    ImageView i1;
    ImageButton ib1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student);

            i1=findViewById(R.id.imageView2);
            ib1=findViewById(R.id.imageButton);
            ib1.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    i1.setImageResource(R.drawable.f3);
                }
            });
    }
}
