package com.example.a10yearcha;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;

public class MainActivity extends AppCompatActivity {
    Button b1,b2;
    EditText e1,e2;
    Spinner sp;
    String s1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

           b1=findViewById(R.id.button);
            b2=findViewById(R.id.button2);
            e1=findViewById(R.id.editText);
            e2=findViewById(R.id.editText2);
            sp=findViewById(R.id.spinner);

            ArrayAdapter aa=ArrayAdapter.createFromResource(this,R.array.role,android.R.layout.simple_spinner_item);
            aa.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            sp.setAdapter(aa);
            sp.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                    s1=parent.getItemAtPosition(position).toString();

                }

                @Override
                public void onNothingSelected(AdapterView<?> parent) {

                }
            });

            b1.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {


                    if((e1.getText().toString().equals("abc"))&&(e2.getText().toString().equals("xyz"))&&(s1.equals("faculty"))) {
                        Intent i = new Intent(MainActivity.this, Faculty.class);
                        startActivity(i);
                    }
                    else
                    {
                        Intent i=new Intent(MainActivity.this,Student.class);
                        startActivity(i);
                    }
                }
            });
            b2.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if ((e1.getText().toString().equals("abc")) && (e2.getText().toString().equals("xyz"))) {
                        Intent i = new Intent(MainActivity.this, okoko.class);
                        startActivity(i);
                    }
                }
            });

    }
}
