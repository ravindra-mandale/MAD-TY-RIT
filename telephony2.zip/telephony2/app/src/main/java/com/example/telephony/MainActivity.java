package com.example.telephony;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.telephony.TelephonyManager;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    EditText e1;
    TelephonyManager tm;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        e1=findViewById(R.id.editText);
        tm=(TelephonyManager)  getSystemService(TELEPHONY_SERVICE);
        String name=tm.getSimOperatorName();
        int networktype=tm.getNetworkType();
        int phonetype=tm.getPhoneType();
        String cname=tm.getNetworkCountryIso();
        String ptype=null;
        String ntype=null;

        switch (phonetype)
        {
            case(TelephonyManager.PHONE_TYPE_CDMA):
                ptype="CDMA";
                break;

            case (TelephonyManager.PHONE_TYPE_GSM):
                ptype="GSM";
                break;

            case (TelephonyManager.PHONE_TYPE_NONE):
                    ptype="NONE";
                    break;

        }

        switch(networktype)
        {
            case(TelephonyManager.PHONE_TYPE_CDMA):
                ntype="CDMA";
                break;

            case (TelephonyManager.PHONE_TYPE_GSM):
                ntype="GSM";
                break;

            case (TelephonyManager.PHONE_TYPE_NONE):
                ntype="NONE";
                break;
        }

        String message="Sim operator name="+name+"\n network type=" +ntype+"\n phone Type=" +ptype+"\n Network country=" +cname+"\nSim Country";
        e1.setText(message);
    }
}
