package edureka.com.telephonyandsms_4017;

import android.provider.Telephony;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.telecom.TelecomManager;
import android.telephony.SmsManager;
import android.telephony.TelephonyManager;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
TelephonyManager tm;
TextView tv;
Button b1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tv=findViewById(R.id.textView1);
        b1=findViewById(R.id.button1);
        tm= (TelephonyManager) getSystemService(TELEPHONY_SERVICE);
        String simop=tm.getSimOperatorName();
        int network=tm.getNetworkType();

        String netwoknm;

        switch (network)
        {
            case TelephonyManager.NETWORK_TYPE_GPRS:
                netwoknm="GPRS";
            case TelephonyManager.NETWORK_TYPE_EDGE:
                netwoknm="Edge";
            case TelephonyManager.NETWORK_TYPE_UNKNOWN:
                netwoknm="umknown";
        }
        int phoneType=tm.getPhoneType();
        String phonenm;
        switch (phoneType)
        {
            case TelephonyManager.PHONE_TYPE_CDMA:
                phonenm="CDMA";
            case TelephonyManager.PHONE_TYPE_GSM:
                phonenm="GSM";
            case  TelephonyManager.PHONE_TYPE_NONE:
                phonenm="none";

             default:
                 phonenm="unknown";
        }
       // int simcnt=tm.getPhoneCount();
        String iso1=tm.getNetworkCountryIso();
        String iso2=tm.getSimCountryIso();
        tv.setText(simop+"\n"+iso1+"\n"+iso2+"\n");

    }
    public void sendsms(View v)
    {
        SmsManager sm=SmsManager.getDefault();
        sm.sendTextMessage("+919370703924","+919898051916","hello",null,null);
    }
}
