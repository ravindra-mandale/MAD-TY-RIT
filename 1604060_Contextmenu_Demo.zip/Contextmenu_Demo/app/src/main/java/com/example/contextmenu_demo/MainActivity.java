package com.example.contextmenu_demo;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.ContextMenu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    TextView t1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        t1=findViewById(R.id.hotel_name);
        registerForContextMenu(t1);


    }

    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);
        MenuInflater inflater=getMenuInflater();
        inflater.inflate(R.menu.contextmenu,menu);
        //menu.setHeaderTitle("select the icon");
    }

    @Override
    public boolean onContextItemSelected(MenuItem item) {
        int s1=item.getItemId();

        if (s1==R.id.id_veg)
        {
            Intent i=new Intent(MainActivity.this,second_menu.class);
            startActivity(i);

        }
        if(s1==R.id.id_Nonveg)
        {
            Intent i=new Intent(MainActivity.this,second_menu.class);
            startActivity(i);
        }
        return super.onContextItemSelected(item);
    }
}
