package com.example.database;

import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
Button b1,b2;
EditText e1,e2;
SQLiteDatabase db;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        e1=findViewById(R.id.editText);
        e2=findViewById(R.id.editText2);

        b2=findViewById(R.id.button2);
        b1=findViewById(R.id.button);


        db=openOrCreateDatabase("RIT",MODE_PRIVATE,null);
        Toast.makeText(getApplicationContext(),"database created",Toast.LENGTH_SHORT).show();


        //Toast.makeText(getApplicationContext(),"table is created",Toast.LENGTH_SHORT).show();
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String s1,s2;
                db.execSQL("create table if not exists login(name varchar(20),pass varchar(20))");
                s1=e1.getText().toString();
                s2=e2.getText().toString();
                ContentValues values=new ContentValues();
                values.put("name",s1);
                values.put("pass",s2);

                db.insertOrThrow("login",null,values);

                Toast.makeText(getApplicationContext(),"inserted Data= "+s1+" and "+s2,Toast.LENGTH_LONG).show();

                e1.setText("");
                e2.setText("");
                db.close();
            }
        });

    }
    public  void onclick(View view)
    {
        Intent i=new Intent(this,Login.class);
        startActivity(i);
    }
}
