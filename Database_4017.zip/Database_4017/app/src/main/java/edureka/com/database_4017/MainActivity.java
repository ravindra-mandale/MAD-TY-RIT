package edureka.com.database_4017;

import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    EditText ed1, ed2;
    Button b1, b2;
    SQLiteDatabase db;
    Cursor c;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ed1 = findViewById(R.id.editText1);
        ed2 = findViewById(R.id.editText2);

        b1 = findViewById(R.id.button1);
        b2 = findViewById(R.id.button2);

        db = openOrCreateDatabase("login", MODE_PRIVATE, null);
        db.execSQL("create table if not exists login(name varchar(10),pass varchar(10))");
       b1.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View v) {

               String s1=ed1.getText().toString();
               String s2=ed2.getText().toString();
               ContentValues values=new ContentValues();
               values.put("name",s1);
               values.put("pass",s2);

               db.insertOrThrow("login",null,values);
               c=db.rawQuery("select * from login",null);
               c.moveToNext();

               String nm=c.getString(0);
               String p=c.getString(1);
               Toast.makeText(getApplicationContext(),nm+" values"+p,Toast.LENGTH_SHORT).show();

               ed1.setText("");
               ed2.setText("");

               db.close();

           }
       });

       b2.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View v) {

               Intent i=new Intent(getApplicationContext(),Login_4017.class);
               startActivity(i);

           }
       });
    }
}
