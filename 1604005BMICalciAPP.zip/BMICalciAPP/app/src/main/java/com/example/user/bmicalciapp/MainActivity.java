package com.example.user.bmicalciapp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
Button bt1;
EditText ed1,ed2;
TextView tv;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        bt1=findViewById(R.id.button);
        ed1=findViewById(R.id.editText1);
        ed2=findViewById(R.id.editText2);
        tv=findViewById(R.id.textView3);

        bt1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String s1=ed1.getText().toString();
                String s2=ed2.getText().toString();
                float height=Float.parseFloat((s1));
                float weight=Float.parseFloat((s2));

                float h=height/100;
                float BMItotal=weight/(h*h);

                tv.setText(String.valueOf(BMItotal));

            }
        });

    }
}
