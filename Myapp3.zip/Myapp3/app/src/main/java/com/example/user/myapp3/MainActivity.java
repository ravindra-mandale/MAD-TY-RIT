package com.example.user.myapp3;

import android.content.Context;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
        protected void onStart()
        {
            super.onStart();
            Log.i("onStart","Activity Started");

        }
        protected void onResume()
        {
            super.onResume();
            Log.i("onResume", "Activity Resumed");
        }
    protected void onPause()
    {
        super.onPause();
        Log.i("onPause", "Activity Paused");
    }
    protected void onStop()
    {
        super.onStop();
        Log.i("onPause", "Activity Paused");
    }
    protected void onDestroy()
    {
        super.onDestroy();
        Log.i("onDestroy", "Activity Destroyed");
    }
    protected void onRestart()
    {
        super.onRestart();
        Log.i("onRestart", "Activity Restarted");
    }

}
