package e.roman.sharedpreference;

import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    Button save,display;
    EditText text;
    SharedPreferences sharedPreferences;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        text=findViewById(R.id.editText);
        save=findViewById(R.id.button);
        display=findViewById(R.id.button2);
        sharedPreferences=getSharedPreferences("save",MODE_PRIVATE);
        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            SharedPreferences.Editor editor=sharedPreferences.edit();
            editor.putString("Name_key",text.getText().toString());
                editor.commit();
                Toast.makeText(getApplicationContext(),"OK",Toast.LENGTH_SHORT).show();
            }
        });
        display.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(sharedPreferences.contains("Name_key"))
                {
                    text.setText(sharedPreferences.getString("Name_key",""));
                }
            }
        });

    }
}
