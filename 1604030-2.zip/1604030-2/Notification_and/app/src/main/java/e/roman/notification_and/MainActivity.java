package e.roman.notification_and;


import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.support.v4.app.NotificationCompat;
import android.support.v4.app.NotificationManagerCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    EditText text;
    Button btn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


            btn=findViewById(R.id.button);
            text=findViewById(R.id.editText);
            btn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                Intent intent=new Intent(getApplicationContext(),MainActivity.class);
                    PendingIntent pIntent=PendingIntent.getActivity(getApplicationContext(),1,intent,0);

                    Notification builder = new Notification.Builder(getApplicationContext())
                            //.setDefaults(NotificationCompat.DEFAULT_ALL)
                            .setContentTitle("notify")
                            .setSmallIcon(R.drawable.ic_launcher_background)
                            .setContentIntent(pIntent)
                            .setContentText("hello")
                            .build();

 //                           .setContentIntent(pintent);

                    NotificationManager notificationManager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
                    // hide the notification after its selected
                   // builder.flags |= Notification.FLAG_AUTO_CANCEL;

                    notificationManager.notify(0, builder);


                }
            });


    }

}
