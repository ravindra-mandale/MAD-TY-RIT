package com.example.a10yrchallenge;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;

public class MainActivity extends AppCompatActivity {
Spinner sp;
    String s1;
    EditText e1,e2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        String[] domain={"student","Faculty"};
        e1=findViewById(R.id.editText);
        e2=findViewById(R.id.editText3);
        sp=findViewById(R.id.spinner);

        ArrayAdapter aa=new ArrayAdapter(this,android.R.layout.simple_spinner_item,domain);
        aa.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        sp.setAdapter(aa);

        sp.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                s1=parent.getItemAtPosition(position).toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });


    }

    public void onclick(View view)
    {
        String s2=e1.getText().toString();
        String s3=e1.getText().toString();

        if(s2.equals(s3)&&(s1.equals("student")))
        {
            Intent i=new Intent(this,student.class);
            startActivity(i);
        }
        if(s2.equals(s3)&&(s1.equals("Faculty")))
        {
            Intent i=new Intent(this,faculty.class);
            startActivity(i);
        }
    }
}
