package com.india.rit.telephonesms;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.telephony.TelephonyManager;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;


public class MainActivity extends AppCompatActivity {
TelephonyManager tm;
    TextView ed1;
    String networkTypeName,phoneTypeName,isRomingStatus;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ed1=findViewById(R.id.textView);
        tm=(TelephonyManager) getSystemService(TELEPHONY_SERVICE);
        String simOpName = tm.getSimOperatorName();//get sim operator name airtel
        int networkType = tm.getNetworkType();//
        int phoneType = tm.getPhoneType();

        switch (networkType)
        {
            case TelephonyManager.NETWORK_TYPE_LTE:
             networkTypeName="LTE";
             break;
            case TelephonyManager.NETWORK_TYPE_UMTS:
                networkTypeName="UMTS";
            break;
            default:
                networkTypeName="not recognized";
                break;
        }
        switch (phoneType)
        {
            case TelephonyManager.PHONE_TYPE_CDMA:
                phoneTypeName="Cdma";
                break;
            case TelephonyManager.PHONE_TYPE_GSM:
                phoneTypeName="GSM";
                break;
            case TelephonyManager.PHONE_TYPE_SIP:
                phoneTypeName="STP";
                break;

            default:
                networkTypeName="Phone type not recognized";
                break;
        }
        boolean isRoming = tm.isNetworkRoaming();
        if(isRoming==true)
        {
            isRomingStatus="sim is roming" ;
        }
        else
        {
            isRomingStatus="sim is not roming";
        }
        String networkCountryISO = tm.getNetworkCountryIso();

        ed1.setText("sim operator length: "+simOpName+"\n"+"Roming Status:"+isRomingStatus+"\nNetwork type name"+networkTypeName+"\nNetwork country is"+networkCountryISO+"\nPhone type:"+phoneTypeName);



    }

    public void sendSMS(View view) {
        SmsManager smsMang = SmsManager.getDefault();
        smsMang.sendTextMessage("+917028021256","=919898051916","akira loves jun",null,null);//null<- sms is send//null<-delivered sms

    }



}
