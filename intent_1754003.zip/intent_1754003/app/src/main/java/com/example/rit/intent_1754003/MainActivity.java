package com.example.rit.intent_1754003;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends Activity
{
    EditText ed1;
    Button call,dialpad,browser,calllog,camera,Gallery,cantact;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ed1=findViewById(R.id.editText);
        call=findViewById(R.id.button);
        dialpad=findViewById(R.id.button2);
        cantact=findViewById(R.id.button3);
        browser=findViewById(R.id.button4);
        calllog=findViewById(R.id.button5);
        camera=findViewById(R.id.button6);
        Gallery=findViewById(R.id.button7);


        call.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                String s=ed1.getText().toString();
                Intent i=new Intent(Intent.ACTION_CALL,Uri.parse("tel:"+s));
                startActivity(i);
            }
        });
        dialpad.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                String s=ed1.getText().toString();
                Intent i=new Intent(Intent.ACTION_DIAL,Uri.parse("tel:"+s));
                startActivity(i);
            }
        });
        cantact.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                String s=ed1.getText().toString();
                Intent i=new Intent(Intent.ACTION_VIEW,Uri.parse("content://contacts/people/"));
                startActivity(i);
            }
        });
        browser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String s=ed1.getText().toString();
                Intent i=new Intent(Intent.ACTION_VIEW,Uri.parse("https:www.google.com"));
                startActivity(i);
            }
        });
        calllog.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String s=ed1.getText().toString();
                Intent i=new Intent(Intent.ACTION_VIEW,Uri.parse("content://call_log/calls/"));
                startActivity(i);
            }
        });
        Gallery.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String s=ed1.getText().toString();
                Intent i=new Intent(Intent.ACTION_VIEW,Uri.parse("content://media/external/images/media/"));
                startActivity(i);
            }
        });
        camera.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String s=ed1.getText().toString();
                Intent i=new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                startActivity(i);

            }
        });

    }
}
