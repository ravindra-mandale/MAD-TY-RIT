package com.example.multimedia;

import android.media.session.MediaSession;
import android.media.session.MediaSessionManager;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.MediaController;
import android.widget.VideoView;

public class Videoplayer extends AppCompatActivity {

    //MediaSessionManager mediaSessionManager;
    VideoView v;
    Button b;
    //MediaSession mediaSession;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_videoplayer);
        v=findViewById(R.id.videoView);
        b=findViewById(R.id.button2);

                String s1="android.resource://com.example.multimedia/"+R.raw.video;
                        Uri uri=Uri.parse(s1);
                        v.setVideoURI(uri);
                        MediaController m=new MediaController(Videoplayer.this);
                        v.setMediaController(m);
                        v.requestFocus();
                        v.start();



    }
}
