package com.example.sqliteopenhelperdemo;

import android.database.Cursor;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
MyHelper mh;
EditText ed1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mh=new MyHelper(this);
        ed1=findViewById(R.id.editText);
    }
    public void insertrecords(View view)
    {
        String name1=ed1.getText().toString();
        mh.insertData(name1);

    }
    public void fetch(View  view)
    {
        Cursor c= mh.fetch();
        c.moveToNext();
        Toast.makeText(getApplicationContext(),"value is"+c.getString(0),Toast.LENGTH_LONG).show();
    }
}
