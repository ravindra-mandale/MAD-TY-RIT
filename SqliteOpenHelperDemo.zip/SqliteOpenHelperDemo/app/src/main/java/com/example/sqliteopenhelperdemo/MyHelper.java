package com.example.sqliteopenhelperdemo;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class MyHelper extends SQLiteOpenHelper {
    public MyHelper( Context context) {

        super(context, "RIT.db", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table Student(Name varchar(20))");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }

    public void insertData(String name)
    {
        SQLiteDatabase db1=getWritableDatabase();
        ContentValues values=new ContentValues();
        values.put("Name",name);
        db1.insert("Student",null,values);

    }
    public Cursor fetch()
    {
        SQLiteDatabase db2=getReadableDatabase();
        Cursor cursor;
        cursor=db2.rawQuery("select * from Student",null);
        return cursor;
    }


}
