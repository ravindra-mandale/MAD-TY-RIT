package com.example.database_helper;

import android.database.Cursor;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    EditText ed1;
    Myhelper mh;
    String s;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ed1=findViewById(R.id.editText);
        mh=new Myhelper(this);
    }
    public  void insert(View view)
    {
        String name=ed1.getText().toString();
        mh.insertData(name);
        Toast.makeText(getApplicationContext(),"inserted",Toast.LENGTH_LONG).show();
    }
    public void Fetch(View view)
    {

        Cursor c=mh.fetch();
        while(c.moveToNext())
        {
            s=c.getString(0);
        }
        Toast.makeText(getApplicationContext(),s,Toast.LENGTH_LONG).show();
    }
}
