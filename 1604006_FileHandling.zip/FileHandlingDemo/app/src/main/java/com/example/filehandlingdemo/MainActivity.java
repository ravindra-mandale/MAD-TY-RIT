package com.example.filehandlingdemo;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;

public class MainActivity extends AppCompatActivity
{
    EditText d;
    TextView t;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        d=findViewById(R.id.editText);
        t=findViewById(R.id.textView);
    }
    public  void writeData(View view)
    {
        try
        {
            String data1=d.getText().toString();
            FileOutputStream fileOutputStream=openFileOutput("hello.txt",MODE_PRIVATE);
            fileOutputStream.write(data1.getBytes());
            fileOutputStream.close();
        }
        catch (Exception e)
        {
            Toast.makeText(getApplicationContext(),e.toString(),Toast.LENGTH_LONG).show();
        }
    }
    public void readData(View v1)
    {
        try
        {
            InputStreamReader inputStreamReader=new InputStreamReader(openFileInput("hello.txt"));
            BufferedReader bufferedReader=new BufferedReader(inputStreamReader);
            String data3=bufferedReader.readLine();
            t.setText(data3);
            bufferedReader.close();
            inputStreamReader.close();

        }
        catch (Exception e2)
        {
            Toast.makeText(getApplicationContext(),e2.toString(),Toast.LENGTH_LONG).show();
        }

    }

    public void appendData(View view)
    {
        try
        {
            String data1=d.getText().toString();
            FileOutputStream fileAppend = openFileOutput("hello.txt",MODE_APPEND);
            fileAppend.write(data1.getBytes());
        }
        catch (Exception e)
        {
            Toast.makeText(getApplicationContext(),e.toString(),Toast.LENGTH_LONG).show();
        }
    }
}
