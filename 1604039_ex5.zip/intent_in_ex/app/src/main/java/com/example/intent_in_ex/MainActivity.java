package com.example.intent_in_ex;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.telecom.Call;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.net.URI;

public class MainActivity extends AppCompatActivity {
        public Button b1,b2,b3,b4,b5,b6,b7;

        public EditText ed;
        String x;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        b1=findViewById(R.id.button);
        b2=findViewById(R.id.button2);
        b3=findViewById(R.id.button3);
        b4=findViewById(R.id.button4);
        b5=findViewById(R.id.button5);
        b6=findViewById(R.id.button6);
        b7=findViewById(R.id.button7);
        ed=findViewById(R.id.editText);

        b1.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {

                try
                {
                    String s=ed.getText().toString();
                    Intent i = new Intent(Intent.ACTION_DIAL);
                    i.setData(Uri.parse(s));

                    //Toast.makeText(getApplicationContext(),"Exception start",Toast.LENGTH_LONG).show();

                    startActivity(i);
                }
                catch (Exception e)
                {
                    e.printStackTrace();
                    //Toast.makeText(getApplicationContext(),"Exception occured",Toast.LENGTH_LONG).show();
                }
            }
        });

        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i1=new Intent(Intent.ACTION_DIAL);
                i1.setData(Uri.parse("tel:"));
                startActivity(i1);

            }
        });

        b3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i1=new Intent(Intent.ACTION_VIEW,Uri.parse("content://contacts/people"));
                startActivity(i1);
            }
        });

        b4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i1=new Intent(Intent.ACTION_VIEW,Uri.parse("http://www.google.com"));
                startActivity(i1);
            }
        });

        b5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i1=new Intent(Intent.ACTION_VIEW,Uri.parse("content://call_log/calls"));
                startActivity(i1);
            }
        });

        b6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i1=new Intent(Intent.ACTION_VIEW,Uri.parse("content://media/external/images/media"));
                startActivity(i1);
            }
        });

        b7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i1=new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                startActivity(i1);
            }
        });
    }


}
