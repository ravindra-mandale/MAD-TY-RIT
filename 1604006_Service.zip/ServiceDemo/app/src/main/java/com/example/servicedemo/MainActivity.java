package com.example.servicedemo;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    public void play(View v1)
    {
        Intent i=new Intent(this,service.class);
        startService(i);
    }
    public void pause(View v2)
    {
        Intent i=new Intent(this,service.class);
        stopService(i);
    }
}
