package com.example.kbmi_cal_ex22;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    EditText e1, e2;
    Button b1;
    TextView t1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        e1 = findViewById(R.id.editText);
        e2 = findViewById(R.id.editText2);
        b1 = findViewById(R.id.button);
        t1 = findViewById(R.id.textView);

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String s1 = e1.getText().toString();
                String s2 = e2.getText().toString();
                double d = Double.parseDouble(s1);
                double d1 = Double.parseDouble(s2);

                double f2 = (d / (d1 * d1));
                double f3 = f2 * 10000;
                String s3 = String.valueOf(f3);
                t1.setText(s3);

                Toast.makeText(getApplicationContext(), s3, Toast.LENGTH_SHORT).show();


                if (f3 < 10) {
                    t1.setText("underweight");

                } else if (f3 > 10 && f3 < 20) {
                    t1.setText("Normal");
                } else {
                    t1.setText("overweight");
                }
            }
        });
    }
}


