package radioactiveyak_com.android.sharedp;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Main2Activity extends AppCompatActivity {
Button b3,b4;
EditText e3,e4;
public static final  String DEFAULT="N/A";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        e3=findViewById(R.id.editText2);
        e4=findViewById(R.id.editText3);
        b3=findViewById(R.id.button3);
        b4=findViewById(R.id.button4);

        b3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SharedPreferences sp = getSharedPreferences("MyData", Context.MODE_PRIVATE);
               String name= sp.getString("name", DEFAULT);
               String pass= sp.getString("pass", DEFAULT);

                if (name.equals(DEFAULT) || pass.equals(DEFAULT)) {
                    Toast.makeText(getApplicationContext(), "no data found", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(getApplicationContext(), "data found", Toast.LENGTH_SHORT).show();
                    e3.setText(name);
                    e4.setText(pass);

                }
            }

        });

        b4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(Main2Activity.this,MainActivity.class);
                startActivity(i);
            }
        });
    }
}
