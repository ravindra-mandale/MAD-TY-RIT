package com.example.shairedpreferences;

import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    EditText e1,e2;
    Button b1,b2,b3;
    SharedPreferences sp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        e1=findViewById(R.id.editText);
        e2=findViewById(R.id.editText2);
        b1=findViewById(R.id.button);
        b2=findViewById(R.id.button2);
        b3=findViewById(R.id.button3);

        sp=getSharedPreferences("Rit",MODE_PRIVATE);
        if (sp.contains("name"))
        {
            e1.setText(sp.getString("name","Dhanu"));
        }
        if(sp.contains("pass"))
        {
            e1.setText(sp.getString("pass","Dhanu"));
        }


          b1.setOnClickListener(new View.OnClickListener() {
              @Override
              public void onClick(View v) {
                  String s1=e1.getText().toString();
                  String s2=e2.getText().toString();
                  SharedPreferences.Editor ed=sp.edit();
                  ed.putString("nme",s1);
                  ed.putString("pass",s2);
                  ed.commit();
                  Toast.makeText(getApplicationContext(),"store successfully",Toast.LENGTH_LONG).show();

              }
          });

           b2.setOnClickListener(new View.OnClickListener() {
               @Override
               public void onClick(View v) {
                   String nm=sp.getString("name","ok");
                   String pass=sp.getString("pass","ok");
                   e1.setText(""+nm);
                   e2.setText(""+pass);
               }
           });
           b3.setOnClickListener(new View.OnClickListener() {
               @Override
               public void onClick(View v) {
                   e1.setText("");
                   e2.setText("");

               }
           });
    }
}
