package com.rit.ravindra.intentdemo;

import android.content.Intent;
import android.net.Uri;
import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    public void browse(View view)
    {
        Intent i1=new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com"));
        startActivity(i1);
    }
    public void explicit(View view)
    {
        Intent i2=new Intent(this, Second.class);
      /*  i2.putExtra("RIT","College");
        i2.putExtra("RollNo",12);
        i2.putExtra("Division",'A');
        i2.putExtra("Booleankey",true);
        i2.putExtra("average",85.6);
        */
      Bundle b=new Bundle();
      b.putString("RIT","College");
      i2.putExtras(b);
      startActivity(i2);



    }
    public void call(View view)
    {
        Intent i3=new Intent(Intent.ACTION_CALL, Uri.parse("tel:9766147819)"));
        Toast.makeText(getApplicationContext(),Intent.ACTION_CALL,Toast.LENGTH_LONG).show();
        startActivity(i3);
    }
    public void dialpad(View view)
    {
        Intent i4=new Intent(Intent.ACTION_DIAL, Uri.parse("tel:9766147819"));
        startActivity(i4);
    }
    public void contacts(View view)
    {
        Intent i5=new Intent(Intent.ACTION_VIEW, Uri.parse("content://contacts/people/"));
        startActivity(i5);
    }
    public void gallery(View view)
    {
        Intent i6=new Intent(Intent.ACTION_VIEW, Uri.parse("content://media/external/images/media/"));
        startActivity(i6);
    }
    public void camera(View view)
    {
        Intent i6=new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        //startActivityForResult(i7,0);
        startActivity(i6);
    }
    public void calllog(View view)
    {
        Intent i8=new Intent(Intent.ACTION_VIEW, Uri.parse("content://call_log/calls/"));
        startActivity(i8);
    }

}
