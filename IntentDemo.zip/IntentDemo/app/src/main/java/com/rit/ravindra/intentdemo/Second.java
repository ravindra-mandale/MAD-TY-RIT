package com.rit.ravindra.intentdemo;

import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

public class Second extends AppCompatActivity {
TextView tv;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);
        tv=findViewById(R.id.textView);
       /* Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
*/
        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });
        Intent i=getIntent();
/*        int s2=i.getIntExtra("RollNo",12);
        char s3=i.getCharExtra("Division",'C');
        boolean s4=i.getBooleanExtra("Booleankey",true);
        float s5=i.getFloatExtra("average",2.50f);
        Toast.makeText(getApplicationContext(),"Values are"+s1+" "+s2+" "+s3+" "+s4+" "+s5,Toast.LENGTH_LONG).show();
        */
Bundle b=i.getExtras();
String s1=b.getString("RIT");
Toast.makeText(getApplicationContext(),s1,Toast.LENGTH_LONG).show();
    }

}
