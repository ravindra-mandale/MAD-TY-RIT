package com.example.admin.notification;

import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.support.annotation.Nullable;
import android.support.v4.app.NotificationCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity
{
    String channelId;
    Button b1;
    NotificationCompat.Builder blder;

    @Override

    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        b1=(Button) findViewById(R.id.button);
        blder=new NotificationCompat.Builder(this,channelId);
        b1.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                blder.setSmallIcon(R.drawable.ic_launcher_background);
                blder.setContentTitle("Notification");
                blder.setContentText("Please decrease volume");
                Intent ntIntent = new Intent(MainActivity.this,nextPage.class);
                PendingIntent contentIntent=PendingIntent.getActivity(MainActivity.this,0, ntIntent,PendingIntent.FLAG_UPDATE_CURRENT);
                blder.setContentIntent(contentIntent);
                NotificationManager nm=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);
                nm.notify(1,blder.build());
            }
        });
    }


}