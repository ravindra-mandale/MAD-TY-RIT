package com.example.kcal_ex21;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    Button b1,b2,b3,b4;
    EditText et1,et2,et3;
    TextView t1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        b1=findViewById(R.id.button);
        b2=findViewById(R.id.button2);
        b3=findViewById(R.id.button3);
        b4=findViewById(R.id.button4);

        et1=findViewById(R.id.editText);
        et2=findViewById(R.id.editText2);
        t1=findViewById(R.id.textView4);

        b1.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                String s1=et1.getText().toString();
                String s2=et2.getText().toString();
                int a=Integer.parseInt(s1);
                int b=Integer.parseInt(s2);
                int c=a+b;
                String s3=String.valueOf(c);
                t1.setText(s3);
            }
        });
        b2.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                String s1=et1.getText().toString();
                String s2=et2.getText().toString();
                int a=Integer.parseInt(s1);
                int b=Integer.parseInt(s2);
                int c=a-b;
                String s3=String.valueOf(c);
                t1.setText(s3);
            }
        });
        b3.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                String s1=et1.getText().toString();
                String s2=et2.getText().toString();
                int a=Integer.parseInt(s1);
                int b=Integer.parseInt(s2);
                int c=a*b;
                String s3=String.valueOf(c);
                t1.setText(s3);
            }
        });
        b4.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                String s1=et1.getText().toString();
                String s2=et2.getText().toString();
                int a=Integer.parseInt(s1);
                int b=Integer.parseInt(s2);
                int c=a/b;
                String s3=String.valueOf(c);
                t1.setText(s3);
            }
        });
    }
}
