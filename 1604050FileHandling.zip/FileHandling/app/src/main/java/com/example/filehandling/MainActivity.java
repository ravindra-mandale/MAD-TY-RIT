package com.example.filehandling;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;

public class MainActivity extends AppCompatActivity {
Button b1,b2;
EditText e1;
TextView t1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        b1=findViewById(R.id.button1);
        b2=findViewById(R.id.button2);
        e1=findViewById(R.id.editText);
        t1=findViewById(R.id.textView);

    }
    public  void write(View v)
    {
        try
        {
            String path=e1.getText().toString();
            OutputStreamWriter osw=new OutputStreamWriter(openFileOutput("vvv.txt",MODE_PRIVATE));
            osw.write(path);
            osw.close();
        }
        catch(FileNotFoundException e)
        {

        }
        catch(IOException e2)
        {

        }
    }
    public void read(View v)
    {
        try
        {
            InputStreamReader isr=new InputStreamReader(openFileInput("vvv.txt"));
            BufferedReader br=new BufferedReader(isr);
            String path=br.readLine();
            t1.setText(path);
            Toast.makeText(getApplicationContext(),getFilesDir().getAbsolutePath(),Toast.LENGTH_LONG).show();
        }
        catch (FileNotFoundException e)
        {

        }
        catch (Exception e2)
        {

        }
    }
}
