package com.example.alert_app;

import android.content.DialogInterface;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    Button b1;
    AlertDialog.Builder ab;
    AlertDialog ad;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Log.i("onCreate","Activity created");
        b1=findViewById(R.id.button);
        ab=new AlertDialog.Builder(this);

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               // Toast.makeText(getApplicationContext(),"button is clicked",Toast.LENGTH_LONG).show();
                ab.setIcon(R.drawable.horse);
                ab.setTitle("alert");
                ab.setMessage("do you want to uninstall");

                ab.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                        Toast.makeText(getApplicationContext(),"you choose ok action",Toast.LENGTH_LONG).show();

                    }
                });
                ab.setNegativeButton("NO", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Toast.makeText(getApplicationContext(),"you choose No action",Toast.LENGTH_LONG).show();
                    }
                });
                ab.setNeutralButton("cancle", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Toast.makeText(getApplicationContext(),"You choose cancle action",Toast.LENGTH_LONG).show();
                    }
                });
                ad=ab.create();
               // ad.setTitle("alert");
                ad.show();

            }
        });


    }

    protected void onStart()
    {
        super.onStart();
        Log.i("onStart()","Activity Started");
    }

    protected void onResume()
    {
        super.onResume();
        Log.i("onResume()","Activity Resumed");
    }
    protected void onPause()
    {
        super.onPause();
        Log.i("onPause()","Activity paused");
    }

    protected void onStop()
    {
        super.onStop();
        Log.i("onstop()","Activity Stoped");
    }
    protected void onDestroy()
    {
        super.onDestroy();
        Log.i("onDestroy()","Activity Destroyed");
    }
    protected void onRestart()
    {
        super.onRestart();
        Log.i("onRestart()","Activity ReStarted");
    }

}
