package com.example.login;

import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.InputFilter;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.jar.Attributes;

public class MainActivity extends AppCompatActivity {
    Button b1,b2;
    EditText e1,e2,e3;
    SQLiteDatabase db;
    Cursor c;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        b1=findViewById(R.id.button1);
        b2=findViewById(R.id.button2);
        e1=findViewById(R.id.editText1);
        e2=findViewById(R.id.editText2);
        e3=findViewById(R.id.editText3);

        db= openOrCreateDatabase("Login",MODE_PRIVATE,null);
        db.execSQL("create table if not exists Login (Name Varchar(10),Pass varchar(20), Num int)");
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                   String s1= e1.getText().toString();
                   String s2= e2.getText().toString();
                   String s3= e3.getText().toString();

                   ContentValues values = new ContentValues();
                   values.put("Name",s1);
                   values.put("Pass",s2);
                   values.put("Num",s3);

                   db.insertOrThrow("Login", null,values);
                  // db.execSQL("insert into Login values(s1,s2,s3)");
                    c=db.rawQuery("select * from Login",null);
                    c.moveToNext();
                    String nm=c.getString(0);
                    String ps=c.getString(1);
                    Toast.makeText(getApplicationContext(),nm+"and"+ps,Toast.LENGTH_LONG).show();

                   e1.setText("");
                   e2.setText("");
                   e3.setText("");
                   db.close();

            }
        });
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i1=new Intent(getApplicationContext(),Login_Form.class);
                startActivity(i1);
            }
        });
    }
}
