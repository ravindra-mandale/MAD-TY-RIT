package com.example.login;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Login_Form extends MainActivity {
    Button b1,b2;
    EditText e1,e2;
    Cursor c1;
    int flag=0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login__form);

        b1=findViewById(R.id.button1);
        b2=findViewById(R.id.button2);
        e1=findViewById(R.id.editText1);
        e2=findViewById(R.id.editText2);

        db=openOrCreateDatabase("Login",MODE_PRIVATE,null);

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String unm, ps;
                unm = e1.getText().toString();
                ps = e2.getText().toString();
                c1=db.rawQuery("select * from Login",null);
                while (c1.moveToNext()) {
                    if (unm.equals(c1.getString(0)) && ps.equals(c1.getString(1))) {
                        flag=1;
                        Intent i2 = new Intent(getApplicationContext(), Home.class);
                        startActivity(i2);
                    }
                }
                if(flag==0){
                    Toast.makeText(getApplicationContext(),"invalid user",Toast.LENGTH_LONG).show();
                }
            }


        });
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i3=new Intent(getApplicationContext(),MainActivity.class);
                startActivity(i3);
            }
        });
    }

}
