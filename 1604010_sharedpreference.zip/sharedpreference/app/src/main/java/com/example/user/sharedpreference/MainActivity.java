package com.example.user.sharedpreference;

import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
Button b1,b2,b3;
EditText e1,e2;
SharedPreferences sp;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        sp=getSharedPreferences("RIT",MODE_PRIVATE);
        e1=findViewById(R.id.editText);
        e2=findViewById(R.id.editText2);
        b1=findViewById(R.id.button);
        b2=findViewById(R.id.button2);
        b3=findViewById(R.id.button3);
        if(sp.contains("name"))
        {
            e1.setText(sp.getString("name","pre"));
        }
        if(sp.contains("mobile"))
        {
            Integer mob=sp.getInt("mobile",1);
            String s2=mob.toString();
            e2.setText(s2);
        }
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String nm=e1.getText().toString();
                int mob=Integer.parseInt(e2.getText().toString());


                SharedPreferences.Editor ed=sp.edit();

                ed.putString("name",nm);
                ed.putInt("mobile",mob);
                ed.commit();
            }
        });
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                e1.setText("");
                e2.setText("");
            }
        });
        b3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String s1=sp.getString("name","pre");
                Integer mob=sp.getInt("mobile",1);
                e1.setText(s1);
                String s2=mob.toString();
                e2.setText(s2);

            }
        });

    }
}
