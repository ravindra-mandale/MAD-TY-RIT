package com.example.filehandling;

import android.os.Environment;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;

public class MainActivity extends AppCompatActivity {

    EditText ed1;
    TextView t1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ed1=findViewById(R.id.editText);
        t1=findViewById(R.id.textView);

    }
    public  void write(View view)
    {
       String name =ed1.getText().toString();
       try
       {
           OutputStreamWriter osw=new OutputStreamWriter(openFileOutput("student.txt",MODE_PRIVATE));
           osw.write(name);
           osw.close();
       }
       catch(FileNotFoundException e)
        {
            e.printStackTrace();
        }
        catch (IOException e)
        {
           e.printStackTrace();
        }


    }

    public  void read(View view)
    {
        try {
    InputStreamReader isr = new InputStreamReader(openFileInput("student.txt"));
            BufferedReader br=new BufferedReader(isr);
            String name=br.readLine();
            t1.setText(name);
            //getFilesDir();
           // getFilesDir().getAbsolutePath(); give file path
            Toast.makeText(getApplicationContext(), getFilesDir().getAbsolutePath(),Toast.LENGTH_LONG).show();
        }
            catch(FileNotFoundException e)
            {
                e.printStackTrace();
            }
            catch (IOException e)
            {
                e.printStackTrace();
            }

    }

    public  void writecard(View view)
    {
        try {
            File myFile = new File("/sdcard/mysdfile.txt");
            myFile.createNewFile();
            FileOutputStream fOut = new FileOutputStream(myFile);
            OutputStreamWriter myOutWriter =
                    new OutputStreamWriter(fOut);
            myOutWriter.append(ed1.getText());
            myOutWriter.close();
            fOut.close();
            Toast.makeText(getBaseContext(),
                    "Done writing SD 'mysdfile.txt'",
                    Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(getBaseContext(), e.getMessage(),
                    Toast.LENGTH_SHORT).show();
        }
      //Toast.makeText(getApplicationContext(),Environment.getExternalStorageState(),Toast.LENGTH_LONG).show();

    }

    public  void readcard(View view)
    {
        try {
            File myFile = new File("/sdcard/mysdfile.txt");
            FileInputStream fIn = new FileInputStream(myFile);
            BufferedReader myReader = new BufferedReader(
                    new InputStreamReader(fIn));
            String aDataRow = "";
            String aBuffer = "";
            while ((aDataRow = myReader.readLine()) != null) {
                aBuffer += aDataRow + "\n";
            }
            t1.setText(aBuffer);
            myReader.close();
            Toast.makeText(getBaseContext(),
                    "Done reading SD 'mysdfile.txt'",
                    Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(getBaseContext(), e.getMessage(),
                    Toast.LENGTH_SHORT).show();
        }

    }
}
