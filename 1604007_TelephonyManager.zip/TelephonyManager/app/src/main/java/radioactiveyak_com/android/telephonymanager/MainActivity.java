package radioactiveyak_com.android.telephonymanager;

import android.Manifest;
import android.annotation.TargetApi;
import android.content.pm.PackageManager;
import android.os.Build;
import android.support.annotation.RequiresApi;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.telephony.TelephonyManager;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    TelephonyManager tm;
    Button b;
//    @RequiresApi(api = Build.VERSION_CODES.O)
//    @RequiresApi(api = Build.VERSION_CODES.M)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        b=findViewById(R.id.button);

        tm = (TelephonyManager) getSystemService(TELEPHONY_SERVICE);

        final String simop = tm.getSimOperatorName();
        final int networkType = tm.getNetworkType();
        String nwnm;
        switch (networkType) {
            case TelephonyManager.NETWORK_TYPE_CDMA:
                nwnm = "CDMA";
            case TelephonyManager.NETWORK_TYPE_EDGE:
                nwnm = "EDGE";
            case TelephonyManager.NETWORK_TYPE_EHRPD:
                nwnm = "EHRPD";
        }

        final int phoneType = tm.getPhoneType();
        String phnm;
        switch (phoneType) {
            case TelephonyManager.PHONE_TYPE_CDMA:
                phnm = "CDMA";
            case TelephonyManager.PHONE_TYPE_GSM:
                phnm = "GSM";
            case TelephonyManager.PHONE_TYPE_NONE:
                phnm = "NONE";
        }

//        int simcnt = tm.getPhoneCount();
//        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) {
//            // TODO: Consider calling
//            //    ActivityCompat#requestPermissions
//            // here to request the missing permissions, and then overriding
//            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
//            //                                          int[] grantResults)
//            // to handle the case where the user grants the permission. See the documentation
//            // for ActivityCompat#requestPermissions for more details.
//            return;
//        }
//        String imei = tm.getImei();
//

        final String iso1=tm.getNetworkCountryIso();
        final String iso2=tm.getSimCountryIso();

        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getApplicationContext(),simop+"\n"+networkType+"\n"+phoneType+"\n"+iso1+"\n"+iso2+"\n",Toast.LENGTH_LONG).show();
            }
        });
    }
}
