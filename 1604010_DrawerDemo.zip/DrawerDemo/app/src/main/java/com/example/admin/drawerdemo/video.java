package com.example.admin.drawerdemo;

import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.MediaController;
import android.widget.VideoView;

public class video extends AppCompatActivity {
    Button b1;
    MediaController mediaController;
    VideoView vv;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_video);
        b1=findViewById(R.id.button1);
        mediaController=new MediaController(this);
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String path="android.resource://com.example.admin.drawerdemo"+R.raw.a;
                Uri uri=Uri.parse(path);
                vv.setVideoURI(uri);
                vv.setMediaController(mediaController);
                vv.requestFocus();
                vv.start();

            }
        });
    }
}
