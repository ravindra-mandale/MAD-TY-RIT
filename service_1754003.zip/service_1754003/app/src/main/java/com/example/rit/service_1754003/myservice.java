package com.example.rit.service_1754003;

import android.app.Service;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.IBinder;

public class myservice extends Service
{
    MediaPlayer mp;
      //@androidx.annotation.Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
    public void onCreate()
    {
        super.onCreate();
        mp=MediaPlayer.create(this,R.raw.my);

    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        mp.start();
        return super.onStartCommand(intent, flags, startId);
    }

    public void onDestroy()
    {
        mp.stop();
    }

}
