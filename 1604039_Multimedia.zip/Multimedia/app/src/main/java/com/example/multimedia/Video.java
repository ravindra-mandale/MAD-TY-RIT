package com.example.multimedia;

import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.MediaController;
import android.widget.VideoView;

public class Video extends AppCompatActivity {
        VideoView vv;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_video);
        vv=findViewById(R.id.videoView);
        String path="android.resource://com.example.multimedia/"+R.raw.my;
        Uri uri=Uri.parse(path);
        vv.setVideoURI(uri);
        MediaController mediaController=new MediaController(Video.this);
        vv.setMediaController(mediaController);
        vv.requestFocus();
        vv.start();
    }
}
