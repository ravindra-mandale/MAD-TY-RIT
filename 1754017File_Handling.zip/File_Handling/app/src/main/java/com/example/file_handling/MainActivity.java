package com.example.file_handling;

import android.content.Intent;
import android.net.Uri;
import android.provider.MediaStore;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.zip.Inflater;

public class MainActivity extends AppCompatActivity {

    Button b1,b2;
    EditText e1;

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu,menu);
        return super.onCreateOptionsMenu(menu);
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id=item.getItemId();
        if(id==R.id.item2)
        {
            Intent i=new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            startActivity(i);
        }
        if(id==R.id.item1)
        {
            Intent i=new Intent(Intent.ACTION_VIEW, Uri.parse("content://media/external/images/media"));
            startActivity(i);
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        b1=findViewById(R.id.button);
        b2=findViewById(R.id.button2);
        e1=findViewById(R.id.editText);

        ActionBar ab=getSupportActionBar();
        ab.setDisplayHomeAsUpEnabled(true);
        ab.setTitle("ActionBarApp");




        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                try {
                    String s1=e1.getText().toString();

                    OutputStreamWriter o = new OutputStreamWriter(openFileOutput("abc.txt", MODE_PRIVATE));
                    o.write(s1);
                    o.close();
                }
                catch(FileNotFoundException e)
                {

                }
                catch(IOException i)
                {

                }
            }
        });

        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                try {
                    InputStreamReader r = new InputStreamReader(openFileInput("abc.txt"));
                    BufferedReader br = new BufferedReader(r);
                    String data = br.readLine();
                    e1.setText(data);
                    Toast.makeText(getApplicationContext(),getFilesDir().getAbsolutePath(),Toast.LENGTH_SHORT).show();
                }
                catch(FileNotFoundException e)
                {

                }
                catch(IOException i)
                {


                }



            }
        });



    }
}
